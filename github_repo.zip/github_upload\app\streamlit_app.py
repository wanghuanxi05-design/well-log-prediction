r"""Streamlit 演示：测井 DTC 预测。

启动：
    .\.venv\Scripts\streamlit.exe run app\streamlit_app.py
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import streamlit as st

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import config as C  # noqa: E402
from data_prep import load_meta  # noqa: E402
from evaluation import compute_metrics  # noqa: E402
from inference import predict_gbdt, prepare_features, read_las  # noqa: E402
from predict import plot_well  # noqa: E402

st.set_page_config(page_title="测井 DTC 预测演示", page_icon="🛢️", layout="wide")

CSS = """
<style>
.block-container {padding-top: 1.6rem; padding-bottom: 2rem;}
h1, h2, h3 {color: #1f3b57;}
.metric-card {background: #f4f7fb; border-left: 5px solid #2f6f9f; border-radius: 8px;
              padding: 14px 18px; margin-bottom: 8px;}
.metric-card .v {font-size: 26px; font-weight: 700; color: #1f3b57;}
.metric-card .l {font-size: 13px; color: #5b6b7a;}
.small {color: #6b7a89; font-size: 13px;}
</style>
"""
st.markdown(CSS, unsafe_allow_html=True)


# --------------------------------------------------------------------------
# 资源加载
# --------------------------------------------------------------------------
@st.cache_resource
def get_gbdt(use_lith: bool = True):
    import joblib

    if use_lith:
        model = joblib.load(C.OUT_MODEL / "gbdt_l31_lith.joblib")
        info = json.loads((C.OUT_TAB / "metrics_gbdt_l31_lith.json").read_text(encoding="utf-8"))
    else:
        model = joblib.load(C.OUT_MODEL / "gbdt_l31.joblib")
        info = json.loads((C.OUT_TAB / "metrics_gbdt_l31.json").read_text(encoding="utf-8"))
    return model, info


@st.cache_data
def list_las():
    return sorted(C.DATA_LAS.glob("*.las"))


@st.cache_data
def read_las_cached(path: str):
    return read_las(path)


def load_metric(name: str) -> dict | None:
    p = C.OUT_TAB / f"metrics_{name}.json"
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else None


# --------------------------------------------------------------------------
# 页面
# --------------------------------------------------------------------------
def page_overview():
    st.title("🛢️ 基于多曲线与深度学习的测井声波时差（DTC）预测")
    st.markdown(
        "**FORCE 2020 公开数据 · 98 口井 / 117 万采样点 · 18 条常规曲线 + 缺失掩码 + 深度趋势**"
    )

    res = load_metric("gbdt_l31_lith")
    if res:
        c1, c2, c3, c4 = st.columns(4)
        cards = [
            (f"{res['all']['R2']:.3f}", "整体 R2（全部测试行）"),
            (f"{res['all']['R2_within_median']:.3f}", "单井内 R2 中位数"),
            (f"{res['all']['MAE']:.2f}", "MAE (μs/ft)"),
            ("0.635 → 0.885", "旧版 → 新版 单井 R2"),
        ]
        for col, (v, l) in zip([c1, c2, c3, c4], cards):
            with col:
                st.markdown(f"<div class='metric-card'><div class='v'>{v}</div><div class='l'>{l}</div></div>",
                            unsafe_allow_html=True)
        st.markdown(
            "<div class='small'>评测口径：按井划分 69 训练 / 29 测试；单井内 R2 是每口井单独算 R2 后取中位数，"
            "避免被井间 DTC 基准差异“撑高”。</div>", unsafe_allow_html=True)

    st.subheader("技术路线")
    st.markdown(
        "1. **数据清洗**：按物理范围剔除异常值；DTC 缺失或 GR 缺失才删行，其余曲线用「填中位数 + 0/1 掩码」保留。\n"
        "2. **按井划分**：69 口训练 / 29 口测试，绝不按行随机分，防止同井相邻点泄漏。\n"
        "3. **特征**：18 条曲线（GR、RHOB、NPHI、RDEP、CALI、SP、PEF、DTS…）+ 掩码 + 深度 + 井内标准化。\n"
        "4. **模型**：GBDT 主模型；线性回归、MLP、U-Net 作为对照。\n"
        "5. **评测**：MAE / RMSE / 整体 R2 / 单井内 R2 中位数。"
    )

    st.subheader("模型对比")
    rows = []
    prev = {"模型": "上一版（报告值）", "整体R2": 0.836, "单井R2中位数": 0.635, "MAE": 7.38,
            "RMSE": "—", "单井R2均值": "—", "测试点数": "—", "测试井数": "—"}
    rows.append(prev)
    for name, label in [
        ("lr_core4_nodepth", "线性回归（4 曲线，core4 口径）"),
        ("mlp_core4", "MLP（4 曲线，core4 口径）"),
        ("gbdt_core4", "GBDT（4 曲线+深度，core4 口径）"),
        ("gbdt_l31", "GBDT（18 曲线+深度，31 叶子）"),
        ("gbdt_l31_lith", "GBDT（31 叶子 + 岩性，主模型）"),
        ("unet_w48", "1D U-Net（18 曲线，宽度 48）"),
    ]:
        m = load_metric(name)
        if m:
            row = dict(m["row_all"])
            row["模型"] = label
            rows.append(row)
    st.dataframe(pd.DataFrame(rows).fillna("—"), width="stretch", hide_index=True)

    c1, c2 = st.columns(2)
    with c1:
        if (C.OUT_FIG / "data_coverage.png").exists():
            st.image(str(C.OUT_FIG / "data_coverage.png"), caption="曲线覆盖率")
    with c2:
        if (C.OUT_FIG / "fig_model_compare.png").exists():
            st.image(str(C.OUT_FIG / "fig_model_compare.png"), caption="模型效果对比")


def page_predict():
    st.title("单井预测")
    st.markdown("选择示例 LAS，或上传一口井的 LAS 文件。缺少的曲线会自动用掩码处理，不需要补齐。")

    las_files = list_las()
    option = st.radio("数据来源", ["示例井（data/las）", "上传 LAS"], horizontal=True)
    df, well_name = None, None
    if option == "示例井（data/las）":
        labels = [p.stem.replace("_", "/") for p in las_files]
        pick = st.selectbox("选择井", range(len(labels)), format_func=lambda i: labels[i])
        df, well_name = read_las_cached(str(las_files[pick]))
    else:
        up = st.file_uploader("上传 .las 文件", type=["las", "LAS"])
        if up is not None:
            tmp = C.OUT_PRED / f"upload_{up.name}"
            tmp.write_bytes(up.getbuffer())
            df, well_name = read_las_cached(str(tmp))

    if df is None:
        st.info("请选择或上传 LAS 文件")
        return

    use_lith = "FORCE_2020_LITHOFACIES_LITHOLOGY" in df.columns
    meta = load_meta()
    gm, ginfo = get_gbdt(use_lith)
    curves = ginfo["curves"]
    x, depth, lith, xg, xw, mask, dz, _ = prepare_features(df, meta, curves, True, use_lith)

    if st.button("开始预测", type="primary"):
        with st.spinner("推理中..."):
            pred = predict_gbdt(
                gm, curves, xg, xw, mask, dz, lith,
                use_well_norm=bool(ginfo["args"].get("well_norm", False)),
                use_lith=bool(ginfo["args"].get("lith", False)),
            )

        coverage = float(mask.mean())
        c1, c2, c3 = st.columns(3)
        metrics = None
        if "DTC" in df.columns and df["DTC"].notna().any():
            ok = df["DTC"].notna().to_numpy()
            metrics = compute_metrics(df.loc[ok, "DTC"].to_numpy(), pred[ok], np.zeros(int(ok.sum()), dtype=int))
            c1.metric("MAE", f"{metrics['MAE']:.2f} μs/ft")
            c2.metric("R2", f"{metrics['R2']:.3f}")
            c3.metric("曲线覆盖率", f"{coverage*100:.0f}%")
        else:
            c1.metric("采样点", f"{len(df):,}")
            c2.metric("曲线覆盖率", f"{coverage*100:.0f}%")
            c3.metric("DTC", "无实测值")

        png = C.OUT_PRED / f"app_{well_name.replace('/', '_')}.png"
        plot_well(df, pred, f"{well_name}  DTC 预测", png, metrics)
        st.image(str(png), width="stretch")

        out = pd.DataFrame({"DEPTH_MD": depth, "DTC_pred": pred})
        if "DTC" in df.columns:
            out["DTC_true"] = df["DTC"].to_numpy()
        st.download_button("下载预测结果 CSV", out.to_csv(index=False).encode("utf-8-sig"),
                           file_name=f"{well_name.replace('/', '_')}_DTC_pred.csv", mime="text/csv")
        missing = [c for c in curves if c not in df.columns]
        if missing:
            st.caption("该井缺少曲线（已用掩码处理）：" + "、".join(missing))


def page_analysis():
    st.title("结果分析")
    tabs = st.tabs(["逐井效果", "预测散点", "残差", "曲线消融", "深度趋势"])
    with tabs[0]:
        if (C.OUT_FIG / "fig_perwell_r2.png").exists():
            st.image(str(C.OUT_FIG / "fig_perwell_r2.png"), width="stretch")
        p = C.OUT_TAB / "per_well_gbdt_l31_lith.csv"
        if p.exists():
            st.dataframe(pd.read_csv(p).sort_values("R2"), width="stretch", hide_index=True)
    with tabs[1]:
        if (C.OUT_FIG / "fig_scatter.png").exists():
            st.image(str(C.OUT_FIG / "fig_scatter.png"), width="content")
    with tabs[2]:
        if (C.OUT_FIG / "fig_residual.png").exists():
            st.image(str(C.OUT_FIG / "fig_residual.png"), width="content")
    with tabs[3]:
        if (C.OUT_FIG / "fig_ablation.png").exists():
            st.image(str(C.OUT_FIG / "fig_ablation.png"), width="stretch")
    with tabs[4]:
        if (C.OUT_FIG / "fig_dtc_depth.png").exists():
            st.image(str(C.OUT_FIG / "fig_dtc_depth.png"), width="content")


# --------------------------------------------------------------------------
PAGES = {"项目概览": page_overview, "单井预测": page_predict, "结果分析": page_analysis}
with st.sidebar:
    st.header("测井 DTC 预测")
    choice = st.radio("页面", list(PAGES))
    st.markdown("---")
    st.markdown("**课程**：人工智能概论与实战  \n**数据**：FORCE 2020  \n**模型**：多曲线 + 掩码 + GBDT/U-Net")
    st.caption("预测结果仅用于课程演示。")

PAGES[choice]()
