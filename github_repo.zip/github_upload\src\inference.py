"""单井推理：把 LAS / CSV 的一口井变成模型输入，输出 DTC 预测。

训练与推理必须用完全相同的特征工程，否则会出现「训练用 11 点、预测用 3 点」那类事故。
这里所有标准化参数都从 data/processed/meta.json 读取，井内标准化参数由该井自身曲线现算。
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

import config as C
from data_prep import robust_stats, zscore


# --------------------------------------------------------------------------
# 读数据
# --------------------------------------------------------------------------
def read_las(path: str | Path) -> tuple[pd.DataFrame, str]:
    """读 LAS，返回带 DEPTH_MD 和曲线列的 DataFrame。"""
    import lasio

    las = lasio.read(str(path))
    raw = str(las.well.WELL.value).strip() if "WELL" in las.well else ""
    well_name = raw.split()[0] if raw else Path(path).stem
    df = las.df().reset_index()
    # LAS 里同时有 DEPT（索引，真正深度）和 DEPTH_MD（曲线，常有缺失）；
    # 统一用 DEPT 作为深度，避免两列重名 / 取到缺失的 DEPTH_MD。
    if "DEPT" in df.columns:
        drop = [c for c in ("DEPTH_MD",) if c in df.columns]
        df = df.drop(columns=drop).rename(columns={"DEPT": "DEPTH_MD"})
    df = df.loc[:, ~df.columns.duplicated()].copy()
    if "DEPTH_MD" not in df.columns:
        raise ValueError(f"{path} 中没有 DEPTH_MD / DEPT 列")
    df = df.dropna(subset=["DEPTH_MD"]).sort_values("DEPTH_MD").reset_index(drop=True)
    return df, well_name


def read_csv_well(path: str | Path, well: str) -> tuple[pd.DataFrame, str]:
    """从 FORCE 训练集 csv 中取一口井。"""
    df = pd.read_csv(path, sep=";")
    df = df[df["WELL"] == well].sort_values("DEPTH_MD").reset_index(drop=True)
    if df.empty:
        raise ValueError(f"csv 中找不到井 {well}")
    return df, well


# --------------------------------------------------------------------------
# 特征工程（与 data_prep.py 保持一致）
# --------------------------------------------------------------------------
def prepare_features(
    df: pd.DataFrame,
    meta: dict,
    curves: list[str],
    use_well_norm: bool = True,
    use_lith: bool = False,
):
    """返回 x (n, C)、depth、lith、原始曲线 DataFrame。"""
    depth = df["DEPTH_MD"].to_numpy(dtype=np.float64)
    n = len(df)
    F = len(curves)
    values = np.full((n, F), np.nan, dtype=np.float32)
    for j, col in enumerate(curves):
        if col not in df.columns:
            continue
        v = np.array(pd.to_numeric(df[col], errors="coerce").to_numpy(dtype=np.float64), copy=True)
        lo, hi = C.PHYS_RANGE.get(col, (-np.inf, np.inf))
        v[~np.isfinite(v) | (v < lo) | (v > hi)] = np.nan
        if col in C.LOG_CURVES:
            v = np.log10(np.clip(v, lo, hi))
        values[:, j] = v

    scaler = meta["global_scaler"]
    g_med = np.asarray(scaler["median"], dtype=np.float64)[:F]
    g_scale = np.asarray(scaler["scale"], dtype=np.float64)[:F]
    mask = np.isfinite(values).astype(np.float32)
    x_global = np.zeros((n, F), dtype=np.float32)
    for j in range(F):
        ok = np.isfinite(values[:, j])
        x_global[ok, j] = zscore(values[ok, j].astype(np.float64), g_med[j], g_scale[j]).astype(np.float32)

    x_well = np.zeros((n, F), dtype=np.float32)
    if use_well_norm:
        # 只用曲线较全的层段估井内统计量，避免浅表无曲线段把中位数拉偏
        enough = mask.sum(axis=1) >= max(2, F // 3)
        for j in range(F):
            med, scale = robust_stats(values[enough, j])
            ok = np.isfinite(values[:, j])
            x_well[ok, j] = zscore(values[ok, j].astype(np.float64), med, scale).astype(np.float32)

    d_med = float(scaler["depth_median"])
    d_scale = float(scaler["depth_scale"])
    depth_z = zscore(depth, d_med, d_scale).astype(np.float32)
    rel = ((depth - depth.min()) / max(depth.max() - depth.min(), 1e-6)).astype(np.float32)

    parts = [x_global, mask]
    if use_well_norm:
        parts.append(x_well)
    parts += [depth_z.reshape(-1, 1), rel.reshape(-1, 1)]
    x = np.hstack(parts).astype(np.float32)

    lith = np.full(n, C.UNKNOWN_LITH_ID, dtype=np.int64)
    if use_lith:
        col = "FORCE_2020_LITHOFACIES_LITHOLOGY"
        if col in df.columns:
            codes = pd.to_numeric(df[col], errors="coerce").fillna(-1).to_numpy()
            lith = C.lith_to_id(codes).astype(np.int64)
        else:
            raise ValueError("该数据没有岩性列 FORCE_2020_LITHOFACIES_LITHOLOGY，请换用不带 --lith 的模型")
    return x, depth, lith, x_global, x_well, mask, depth_z, values


# --------------------------------------------------------------------------
# 模型加载与预测
# --------------------------------------------------------------------------
def load_unet(ckpt_path: str | Path, device):
    import torch

    from models import UNet1D

    ckpt = torch.load(str(ckpt_path), map_location=device, weights_only=False)
    a = ckpt["args"]
    model = UNet1D(
        ckpt["n_channels"], width=a["width"], depth=a["depth"],
        lith_classes=C.N_LITH if a.get("lith") else 0, dropout=a.get("dropout", 0.0),
    ).to(device)
    model.load_state_dict(ckpt["state_dict"])
    model.eval()
    return model, ckpt


def predict_unet(model, ckpt, x, lith, meta, device, stride: int | None = None):
    """滑窗预测，返回原始单位 DTC。"""
    from seq_data import PAD, predict_well

    a = ckpt["args"]
    length = a["length"]
    stride = stride or a.get("stride", 64)
    xp = np.pad(x, ((PAD, PAD), (0, 0)), mode="edge")
    well = {"x": xp, "n": len(x), "lith": lith}
    pz = predict_well(model, well, length, stride, device)
    return pz * meta["target_scale"] + meta["target_median"]


def predict_gbdt(model, curves, x_global, x_well, mask, depth_z, lith, use_well_norm=True, use_lith=False):
    """GBDT 走逐点特征，不需要窗口。"""
    from train_point import build_X

    data_like = {
        "x_global": x_global,
        "x_well": x_well if use_well_norm else np.zeros_like(x_global),
        "mask": mask,
        "depth_z": depth_z.reshape(-1),
        "lith": lith.astype(np.int8),
    }
    X, _ = build_X(data_like, curves, use_well_norm, use_lith, True)
    return model.predict(X)
