r"""训练 1D U-Net 序列模型：输入一口井连续 256 个采样点的多曲线序列，输出整段 DTC。

运行示例：
    .\.venv\Scripts\python.exe src\train_unet.py --name unet_all --curves all
    .\.venv\Scripts\python.exe src\train_unet.py --name unet_lith --curves all --lith --epochs 14
"""
from __future__ import annotations

import argparse
import json
import time

import numpy as np
import torch
import torch.nn as nn

import config as C
from data_prep import load_cache
from evaluation import compute_metrics, per_well_table, summarize_row
from models import UNet1D, count_params
from seq_data import SeqData, predict_well


def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument("--name", type=str, default="unet_all")
    ap.add_argument("--curves", type=str, default="all", help="all 或逗号分隔的曲线名")
    ap.add_argument("--length", type=int, default=256)
    ap.add_argument("--width", type=int, default=32)
    ap.add_argument("--depth", type=int, default=4)
    ap.add_argument("--bs", type=int, default=32)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--weight_decay", type=float, default=1e-4)
    ap.add_argument("--epochs", type=int, default=12)
    ap.add_argument("--steps", type=int, default=800, help="每 epoch 迭代步数")
    ap.add_argument("--stride", type=int, default=64, help="推理滑窗步长")
    ap.add_argument("--no_well_norm", action="store_true")
    ap.add_argument("--lith", action="store_true")
    ap.add_argument("--dropout", type=float, default=0.1)
    ap.add_argument("--noise", type=float, default=0.0, help="输入高斯噪声标准差（数据增强）")
    ap.add_argument("--smooth", type=float, default=0.0, help="二阶差分平滑损失权重")
    ap.add_argument("--patience", type=int, default=4)
    ap.add_argument("--val_wells", type=int, default=3,
                    help="从训练井中留出几口做早停；0 表示用全部训练井、固定 epoch")
    return ap.parse_args()


def evaluate(model, seq: SeqData, meta: dict, length: int, stride: int, device, n_rows: int, offsets):
    """对所有测试井滑窗预测，返回逐行预测与指标。"""
    pred_raw = np.full(n_rows, np.nan, dtype=np.float64)
    model.eval()
    for w in seq.test:
        pz = predict_well(model, w, length, stride, device)
        s, e = int(offsets[w["wid"]]), int(offsets[w["wid"] + 1])
        pred_raw[s:e] = pz * meta["target_scale"] + meta["target_median"]
    return pred_raw


if __name__ == "__main__":
    args = parse_args()
    C.seed_everything()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    data, meta = load_cache()
    seq_offsets = data["offsets"]

    curves = list(C.CURVES) if args.curves == "all" else [c.strip() for c in args.curves.split(",") if c.strip()]
    seq = SeqData(data, curves, use_well_norm=not args.no_well_norm, use_lith=args.lith,
                  n_val=args.val_wells)
    n_rows = len(data["target"])
    print(f"井数 {len(seq.wells)}（训练 {len(seq.train)} / 验证 {len(seq.val)} / 测试 {len(seq.test)}），"
          f"通道 {seq.n_channels}，曲线 {len(curves)} 条，岩性={args.lith}")

    model = UNet1D(
        seq.n_channels, width=args.width, depth=args.depth,
        lith_classes=C.N_LITH if args.lith else 0, dropout=args.dropout,
    ).to(device)
    print(f"模型参数量 {count_params(model)/1e6:.2f} M")

    opt = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    total_steps = args.epochs * args.steps
    sched = torch.optim.lr_scheduler.OneCycleLR(
        opt, max_lr=args.lr, total_steps=total_steps, pct_start=0.15, div_factor=10, final_div_factor=50
    )
    scaler = torch.amp.GradScaler("cuda", enabled=device.type == "cuda")
    loss_fn = nn.SmoothL1Loss(beta=1.0)

    has_val = len(seq.val) > 0
    if has_val:
        vx, vy, vl = seq.val_windows(args.length)
        vx_t = torch.from_numpy(vx).to(device)
        vy_t = torch.from_numpy(vy).to(device)
        vl_t = torch.from_numpy(vl).to(device) if vl is not None else None

    rng = np.random.default_rng(C.SEED)
    best_val, best_epoch, bad = float("inf"), -1, 0
    ckpt_path = C.OUT_MODEL / f"{args.name}.pt"
    log_lines = []
    t_start = time.time()

    for epoch in range(1, args.epochs + 1):
        model.train()
        t0 = time.time()
        run_loss = 0.0
        for step in range(args.steps):
            xb, yb, lb = seq.sample_batch(rng, args.bs, args.length)
            if args.noise > 0:
                nc = len(curves)
                xb[:, :nc] += rng.normal(0, args.noise, size=(args.bs, nc, args.length)).astype(np.float32)
                if not args.no_well_norm:
                    xb[:, 2 * nc:3 * nc] += rng.normal(0, args.noise, size=(args.bs, nc, args.length)).astype(np.float32)
            x = torch.from_numpy(xb).to(device, non_blocking=True)
            y = torch.from_numpy(yb).to(device, non_blocking=True)
            l = torch.from_numpy(lb).to(device, non_blocking=True) if lb is not None else None
            with torch.autocast("cuda", dtype=torch.float16, enabled=device.type == "cuda"):
                out = model(x, l)
                loss = loss_fn(out[:, 0, :], y)
                if args.smooth > 0:
                    d2 = out[:, 0, 2:] - 2 * out[:, 0, 1:-1] + out[:, 0, :-2]
                    loss = loss + args.smooth * torch.mean(d2**2)
            opt.zero_grad(set_to_none=True)
            scaler.scale(loss).backward()
            scaler.unscale_(opt)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            scaler.step(opt)
            scaler.update()
            sched.step()
            run_loss += float(loss.detach())

        model.eval()
        if has_val:
            with torch.no_grad(), torch.autocast("cuda", dtype=torch.float16, enabled=device.type == "cuda"):
                vo = model(vx_t, vl_t)
                vloss = float(loss_fn(vo[:, 0, :].float(), vy_t))
        else:
            vloss = float("nan")
        run_loss /= args.steps
        msg = f"epoch {epoch:02d} | train {run_loss:.4f} | val {vloss:.4f} | {time.time()-t0:.0f}s | lr {sched.get_last_lr()[0]:.2e}"
        print(msg)
        log_lines.append(msg)

        if not has_val:
            # 固定 epoch：保存最后一轮
            best_val, best_epoch = vloss, epoch
            torch.save({"state_dict": model.state_dict(), "args": vars(args), "curves": curves,
                        "n_channels": seq.n_channels, "val_loss": vloss}, ckpt_path)
        elif vloss < best_val - 1e-5:
            best_val, best_epoch, bad = vloss, epoch, 0
            torch.save({"state_dict": model.state_dict(), "args": vars(args), "curves": curves,
                        "n_channels": seq.n_channels, "val_loss": vloss}, ckpt_path)
        else:
            bad += 1
        if has_val and bad >= args.patience:
            print(f"早停：连续 {bad} 个 epoch 验证损失未下降")
            break

    ckpt = torch.load(ckpt_path, map_location=device, weights_only=False)
    model.load_state_dict(ckpt["state_dict"])
    print(f"最优 epoch={best_epoch} val={best_val:.4f}，开始全测试井推理...")
    pred_raw = evaluate(model, seq, meta, args.length, args.stride, device, n_rows, data["offsets"])

    is_test = data["is_test"].astype(bool)
    core4 = data["core4"]
    valid = is_test & np.isfinite(pred_raw)
    metrics_all = compute_metrics(data["target"][valid], pred_raw[valid], data["well_id"][valid])
    valid4 = valid & core4
    metrics_core4 = compute_metrics(data["target"][valid4], pred_raw[valid4], data["well_id"][valid4])

    tbl = per_well_table(data["target"][valid], pred_raw[valid], data["well_id"][valid], list(data["well_names"]))
    tbl.to_csv(C.OUT_TAB / f"per_well_{args.name}.csv", index=False, encoding="utf-8-sig")
    np.savez_compressed(C.OUT_PRED / f"pred_{args.name}.npz",
                        pred=pred_raw, y=data["target"], well_id=data["well_id"],
                        is_test=is_test, core4=core4, depth_m=data["depth_m"])

    result = {
        "name": args.name,
        "args": vars(args),
        "curves": curves,
        "params_m": count_params(model) / 1e6,
        "best_epoch": best_epoch,
        "best_val": best_val if has_val else 0.0,
        "train_time_min": (time.time() - t_start) / 60,
        "all": metrics_all,
        "core4": metrics_core4,
        "row_all": summarize_row(args.name, metrics_all),
        "row_core4": summarize_row(args.name, metrics_core4),
    }
    (C.OUT_TAB / f"metrics_{args.name}.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    with open(C.OUT_TAB / f"log_{args.name}.txt", "w", encoding="utf-8") as f:
        f.write("\n".join(log_lines) + "\n" + json.dumps(result["row_all"], ensure_ascii=False) + "\n")

    print("\n== 全部测试行 ==")
    print(json.dumps(result["row_all"], ensure_ascii=False, indent=1))
    print("== core4 测试行（与上一版同口径）==")
    print(json.dumps(result["row_core4"], ensure_ascii=False, indent=1))
    print(f"用时 {(time.time()-t_start)/60:.1f} min，模型 -> {ckpt_path}")
