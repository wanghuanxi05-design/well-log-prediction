r"""数据准备：清洗 FORCE 2020 训练集，生成统一缓存。

流程
    1. 读原始 csv（分号分隔）
    2. 按物理范围把异常值置为 NaN；DTC 无效或 GR 缺失的行直接删除
    3. 按井划分训练/测试（69/29，随机种子 42，与上一版一致）
    4. 计算全局稳健标准化参数（仅用训练井）和每口井的井内稳健标准化参数
    5. 存为 data/processed/dataset.npz + meta.json，供所有模型复用

运行：
    .\.venv\Scripts\python.exe src\data_prep.py            # 有缓存则跳过
    .\.venv\Scripts\python.exe src\data_prep.py --force    # 强制重建
"""
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import numpy as np
import pandas as pd

import config as C

CACHE_NPZ = C.DATA_PROC / "dataset.npz"
CACHE_META = C.DATA_PROC / "meta.json"


# --------------------------------------------------------------------------
# 基础工具
# --------------------------------------------------------------------------
def robust_stats(values: np.ndarray) -> tuple[float, float]:
    """中位数与稳健标准差；数据太少或退化时给安全默认值。"""
    v = values[np.isfinite(values)]
    if v.size < 10:
        return 0.0, 1.0
    med = float(np.median(v))
    q1, q3 = np.percentile(v, [25, 75])
    scale = float((q3 - q1) / 1.349)
    if not np.isfinite(scale) or scale < 1e-8:
        scale = float(np.std(v))
    if not np.isfinite(scale) or scale < 1e-8:
        scale = 1.0
    return med, scale


def zscore(x: np.ndarray, med: float, scale: float, clip: float = 8.0) -> np.ndarray:
    z = (x - med) / scale
    return np.clip(z, -clip, clip)


def load_raw() -> pd.DataFrame:
    usecols = (
        ["WELL", "DEPTH_MD", "X_LOC", "Y_LOC", "Z_LOC", "FORMATION"]
        + list(C.CURVES)
        + ["DTS", "DTC", "FORCE_2020_LITHOFACIES_LITHOLOGY"]
    )
    # 去重并保持顺序
    usecols = list(dict.fromkeys(usecols))
    df = pd.read_csv(C.DATA_RAW, sep=";", usecols=usecols)
    print(f"  原始数据 {len(df):,} 行 × {df.shape[1]} 列，{df.WELL.nunique()} 口井")
    return df


def clean(df: pd.DataFrame) -> pd.DataFrame:
    """物理范围过滤：越界值当作缺失，而不是删行（可选曲线保留掩码）。"""
    n0 = len(df)
    for col, (lo, hi) in C.PHYS_RANGE.items():
        if col not in df.columns:
            continue
        v = df[col].to_numpy(dtype=np.float64)
        bad = ~np.isfinite(v) | (v < lo) | (v > hi)
        df[col] = np.where(bad, np.nan, v)

    # 目标缺失或必需曲线缺失 -> 删行
    before = len(df)
    df = df.dropna(subset=["DTC", "GR"]).copy()
    print(f"  清洗：{n0:,} -> {before:,}（剔除 DTC/GR 无效）-> {len(df):,} 行")
    return df.reset_index(drop=True)


# --------------------------------------------------------------------------
# 划分
# --------------------------------------------------------------------------
def split_wells(wells: list[str]) -> tuple[list[str], list[str]]:
    """按井随机划分，固定种子，保证可复现。"""
    wells = sorted(wells)
    rng = np.random.RandomState(C.SEED)
    perm = rng.permutation(len(wells))
    n_test = C.N_TEST_WELLS
    test = sorted([wells[i] for i in perm[:n_test]])
    train = sorted([wells[i] for i in perm[n_test:]])
    return train, test


# --------------------------------------------------------------------------
# 主流程
# --------------------------------------------------------------------------
def build(force: bool = False) -> None:
    if CACHE_NPZ.exists() and CACHE_META.exists() and not force:
        meta = json.loads(CACHE_META.read_text(encoding="utf-8"))
        if meta.get("cache_version") == C.CACHE_VERSION:
            print(f"缓存已存在（{meta['rows']:,} 行），跳过。加 --force 可重建。")
            return
        print("缓存版本不一致，重建。")

    t0 = time.time()
    print("[1/5] 读取原始数据...")
    df = load_raw()

    print("[2/5] 物理范围清洗...")
    df = clean(df)

    print("[3/5] 划分训练/测试井...")
    wells = sorted(df["WELL"].unique().tolist())
    train_wells, test_wells = split_wells(wells)
    well_to_id = {w: i for i, w in enumerate(wells)}
    df["WELL_ID"] = df["WELL"].map(well_to_id).astype(np.int16)
    df["IS_TEST"] = df["WELL"].isin(test_wells).astype(np.int8)
    print(f"  训练井 {len(train_wells)} 口 / 测试井 {len(test_wells)} 口")

    # 按井、深度排序，保证序列连续
    df = df.sort_values(["WELL_ID", "DEPTH_MD"], kind="mergesort").reset_index(drop=True)

    # ---------- 特征矩阵 ----------
    print("[4/5] 构造特征与标准化参数...")
    n = len(df)
    F = len(C.CURVES)
    values = np.full((n, F), np.nan, dtype=np.float32)
    for j, col in enumerate(C.CURVES):
        v = df[col].to_numpy(dtype=np.float32)
        if col in C.LOG_CURVES:
            lo, hi = C.PHYS_RANGE[col]
            v = np.log10(np.clip(v, lo, hi)).astype(np.float32)
        values[:, j] = v

    is_test = df["IS_TEST"].to_numpy(dtype=bool)
    train_mask = ~is_test

    # 全局稳健标准化参数：只用训练井
    g_med = np.zeros(F, dtype=np.float64)
    g_scale = np.ones(F, dtype=np.float64)
    for j in range(F):
        g_med[j], g_scale[j] = robust_stats(values[train_mask, j])
    x_global = np.zeros((n, F), dtype=np.float32)
    mask = np.isfinite(values).astype(np.float32)
    for j in range(F):
        v = values[:, j].astype(np.float64)
        ok = np.isfinite(v)
        x_global[ok, j] = zscore(v[ok], g_med[j], g_scale[j]).astype(np.float32)

    # 每口井的井内稳健标准化（仅用输入曲线本身，无标签泄漏）
    x_well = np.zeros((n, F), dtype=np.float32)
    well_stats = {}
    well_id_arr = df["WELL_ID"].to_numpy()
    for wid in range(len(wells)):
        idx = np.where(well_id_arr == wid)[0]
        if idx.size == 0:
            continue
        stats = []
        for j in range(F):
            med, scale = robust_stats(values[idx, j])
            v = values[idx, j].astype(np.float64)
            ok = np.isfinite(v)
            x_well[idx[ok], j] = zscore(v[ok], med, scale).astype(np.float32)
            stats.append([round(med, 5), round(scale, 5)])
        well_stats[wells[wid]] = stats

    # 深度特征（全局标准化）
    depth = df["DEPTH_MD"].to_numpy(dtype=np.float64)
    d_med, d_scale = robust_stats(depth[train_mask])
    depth_z = zscore(depth, d_med, d_scale).astype(np.float32)

    # 岩性
    lith = C.lith_to_id(df["FORCE_2020_LITHOFACIES_LITHOLOGY"].fillna(-1).to_numpy())

    target = df["DTC"].to_numpy(dtype=np.float32)
    t_med, t_scale = robust_stats(target[train_mask])
    target_z = ((target - t_med) / t_scale).astype(np.float32)

    # DTS 辅助任务（覆盖率低，仅存原始值）
    dts = df["DTS"].to_numpy(dtype=np.float32)

    # core4 掩码：与上一版完全一致的可用行
    core4_cols = [C.CURVES.index(c) for c in C.CORE4]
    core4 = np.all(mask[:, core4_cols] > 0, axis=1)

    # 井内行偏移（序列模型用）
    well_id = df["WELL_ID"].to_numpy(dtype=np.int16)
    offsets = np.zeros(len(wells) + 1, dtype=np.int64)
    for wid in range(len(wells)):
        offsets[wid + 1] = offsets[wid] + int((well_id == wid).sum())

    print("[5/5] 保存缓存...")
    np.savez_compressed(
        CACHE_NPZ,
        x_global=x_global,
        x_well=x_well,
        mask=mask,
        depth_z=depth_z,
        depth_m=depth.astype(np.float32),
        lith=lith,
        target=target,
        target_z=target_z,
        dts=dts,
        core4=core4,
        well_id=well_id,
        is_test=is_test.astype(np.int8),
        offsets=offsets,
        well_names=np.array(wells, dtype="U32"),
        curve_names=np.array(C.CURVES, dtype="U16"),
    )

    meta = {
        "cache_version": C.CACHE_VERSION,
        "rows": int(n),
        "wells": len(wells),
        "train_wells": train_wells,
        "test_wells": test_wells,
        "curve_names": C.CURVES,
        "core4_rows": int(core4.sum()),
        "core4_test_rows": int((core4 & is_test).sum()),
        "core4_wells": int(len(set(df.loc[core4, "WELL"]))),
        "target_mean": float(np.mean(target[train_mask])),
        "target_std": float(np.std(target[train_mask])),
        "target_median": t_med,
        "target_scale": t_scale,
        "global_scaler": {
            "median": g_med.tolist(),
            "scale": g_scale.tolist(),
            "depth_median": d_med,
            "depth_scale": d_scale,
        },
        # 井内标准化参数：{井名: [[median, scale] × 7]}
        "well_scaler": well_stats,
        "split_seed": C.SEED,
        "n_test_wells": C.N_TEST_WELLS,
        "created": time.strftime("%Y-%m-%d %H:%M:%S"),
    }
    CACHE_META.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"  完成：{n:,} 行，用时 {time.time()-t0:.1f}s")
    print(f"  core4 行数 {core4.sum():,}（测试 {int((core4 & is_test).sum()):,}）")
    print(f"  缓存 -> {CACHE_NPZ}")


def load_meta() -> dict:
    """只读 meta.json（不加载大数组）。"""
    if not CACHE_META.exists():
        raise FileNotFoundError("缺少数据缓存，请先运行 src/data_prep.py")
    return json.loads(CACHE_META.read_text(encoding="utf-8"))


def load_cache() -> tuple[dict, dict]:
    """读取缓存，供训练/评测脚本调用。"""
    if not CACHE_NPZ.exists():
        raise FileNotFoundError("缺少数据缓存，请先运行 src/data_prep.py")
    data = dict(np.load(CACHE_NPZ, allow_pickle=False))
    meta = load_meta()
    return data, meta


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--force", action="store_true", help="强制重建缓存")
    args = ap.parse_args()
    build(force=args.force)
