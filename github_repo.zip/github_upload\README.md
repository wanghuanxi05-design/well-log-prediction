# 基于多曲线机器学习的测井声波时差（DTC）预测

用 18 条常规测井曲线、缺失掩码和深度特征，逐点预测缺失的声波时差 **DTC（μs/ft）**。主模型为 **HistGradientBoosting（GBDT，31 叶子 + 岩性）**，线性回归、MLP、1D U-Net 作为对照。

数据来自 **FORCE 2020** 公开测井数据集（98 口井、117 万采样点），按井划分 69 口训练 / 29 口测试，测试井不参与调参。

## 结果（29 口测试井，33.08 万点）

| 模型 | 整体 R² | 单井内 R² 中位数 | MAE (μs/ft) | RMSE |
|---|---|---|---|---|
| 线性回归（4 曲线） | 0.821 | 0.760 | 9.21 | 12.11 |
| MLP（18 曲线） | 0.865 | 0.818 | 7.84 | 11.22 |
| 1D U-Net（18 曲线） | 0.889 | 0.843 | 7.19 | 10.17 |
| **GBDT（31 叶子 + 岩性）** | **0.898** | **0.885** | **6.86** | **9.77** |

![模型对比](outputs/figures/fig_result_models.png)

![GBDT 参数敏感性](outputs/figures/fig_param_gbdt.png)

## 仓库包含

- **运行代码**：数据准备、GBDT/线性/MLP/U-Net 训练、推理、评测、参数实验、消融、跨象限、绘图。
- **训练好的结果**：最终 GBDT 模型、推理所需 `meta.json`、测试指标 JSON、参数实验 CSV、逐井结果、结果图、单井示例。
- **使用说明**：环境、数据放置、训练/推理/App 命令。
- **不包含**：FORCE 2020 原始数据（`train.csv`、LAS）、`dataset.npz`、预测中间 `npz`、PPT。

```
.
├─ src/                        训练、推理、评测、绘图脚本
│  ├─ config.py                路径、曲线、清洗阈值、特征分组
│  ├─ data_prep.py             清洗、按井划分、标准化、缓存
│  ├─ train_gbdt.py            主模型 GBDT
│  ├─ train_point.py           线性回归 / MLP
│  ├─ train_unet.py            1D U-Net（对照，需要 PyTorch）
│  ├─ inference.py             LAS/CSV 特征工程与 GBDT 推理
│  ├─ predict.py               单井预测命令行（CSV + 四道图）
│  ├─ evaluation.py            整体 R²、单井内 R²、MAE、RMSE
│  ├─ feature_ablation.py      曲线组消融
│  ├─ cross_quadrant.py        留一象限泛化
│  ├─ param_sweep.py           9 口验证井上的参数实验
│  └─ plots.py                 结果图表
├─ app/streamlit_app.py        Streamlit 单井预测演示
├─ data/
│  ├─ README.md                数据下载与放置说明
│  └─ processed/meta.json      推理用全局标准化参数（已包含）
├─ outputs/
│  ├─ models/gbdt_l31_lith.joblib     最终 GBDT 模型（已包含）
│  ├─ tables/                         测试指标、参数实验、逐井结果
│  └─ figures/                        结果图
├─ 示例/                       单井预测示例（CSV + PNG）
├─ requirements.txt
├─ run_all.ps1
├─ 使用说明.md
└─ .gitignore
```

## 快速开始

### 1. 环境

建议 Python 3.10+，Windows / Linux 均可（命令按 Windows 写）：

```powershell
python -m venv .venv
.\.venv\Scripts\activate
pip install -r requirements.txt
```

GBDT 推理和 Streamlit 不需要 GPU。若要复现 U-Net 对照，另行安装 PyTorch：

```powershell
pip install torch
```

### 2. 数据

仓库**不包含** FORCE 2020 原始数据；如果只是用已训练模型做单井预测，只需要准备 LAS：

```
data/las/*.las
```

如果要重新训练，再下载 `train.csv`：

```
data/raw/train.csv     # FORCE 2020 训练表，分号分隔，约 267 MB
```

下载地址与字段说明见 [data/README.md](data/README.md)。

### 3. 直接单井预测（不重新训练）

仓库已带 `outputs/models/gbdt_l31_lith.joblib` 和 `data/processed/meta.json`：

```powershell
python src\predict.py --las "data\las\31_2-19 S.las" --out "示例\31_2-19S_DTC预测"
```

输出逐点 CSV 和 GR / RHOB-NPHI / DTC / 残差四道图。示例结果：

| 井 | MAE | R² | 覆盖率 |
|---|---:|---:|---:|
| 31/2-19 S | 6.75 | 0.872 | 64.9% |

### 4. Web 演示

```powershell
streamlit run app\streamlit_app.py
```

打开终端提示的地址（默认 http://localhost:8501）。App 默认读取已带的 GBDT 模型；示例井需要 `data/las`，没有 LAS 也可以直接上传文件。

### 5. 重新训练（可选）

首次先运行数据准备（生成 `data/processed/dataset.npz`，约 10 分钟）：

```powershell
python src\data_prep.py
python src\train_gbdt.py --name gbdt_l31_lith --curves all --lith --max_iter 500 --lr 0.05 --leaves 31
```

训练完成后会覆盖 `outputs/models/gbdt_l31_lith.joblib`，指标写到 `outputs/tables/`。

### 6. 一键复现（Windows）

```powershell
powershell -ExecutionPolicy Bypass -File .\run_all.ps1
```

会依次执行数据准备、线性/MLP 基线、GBDT 主模型、U-Net 对照、参数实验、消融、跨象限、图表和单井示例。首次约 30 分钟。

> 该脚本包含 U-Net 对照，需先安装 PyTorch；只复现 GBDT 可跳过 `run_all.ps1`，按第 2–4 步执行。

## 训练好的结果文件

| 文件 | 内容 |
|---|---|
| `outputs/models/gbdt_l31_lith.joblib` | 最终 GBDT 模型（31 叶子 + 岩性） |
| `data/processed/meta.json` | 全局标准化参数，推理必需 |
| `outputs/tables/metrics_gbdt_l31_lith.json` | 全部测试行 + core4 指标 |
| `outputs/tables/metrics_gbdt_l31.json` | 不含岩性的 GBDT 对照 |
| `outputs/tables/metrics_unet_w48.json` | U-Net 对照 |
| `outputs/tables/metrics_mlp_all.json` | MLP 对照 |
| `outputs/tables/metrics_lr_core4_nodepth.json` | 线性回归对照 |
| `outputs/tables/param_sweep.csv` | 9 口验证井的 19 组参数实验 |
| `outputs/tables/per_well_gbdt_l31_lith.csv` | 29 口测试井逐井 R² |
| `示例/31_2-19S_DTC预测.csv/.png` | 单井示例结果 |

## 数据与版权

- FORCE 2020 数据版权归原数据集作者，使用前请阅读其许可协议；本仓库不重新分发原始数据。
- 模型和结果仅用于课程学习与演示，不保证适用于其它盆地或商业解释。
