"""统一评测：整体指标 + 单井内部指标（与上一版口径一致）。

为什么单独看「单井内 R2」：
    把所有测试井混在一起算 R2，很大一部分来自井间 DTC 基准差异（有的井 70，有的 150），
    模型只要大致猜中井的基准就能拿高分。单井内 R2 才是真正的曲线形态预测能力。
"""
from __future__ import annotations

import numpy as np
import pandas as pd


def _r2(y: np.ndarray, p: np.ndarray) -> float:
    ss_res = float(np.sum((y - p) ** 2))
    ss_tot = float(np.sum((y - y.mean()) ** 2))
    if ss_tot < 1e-12:
        return float("nan")
    return 1.0 - ss_res / ss_tot


def compute_metrics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    well_ids: np.ndarray,
    min_points: int = 30,
) -> dict:
    """返回 MAE / RMSE / 整体 R2 / 单井内 R2 的中位数与均值。"""
    y_true = np.asarray(y_true, dtype=np.float64)
    y_pred = np.asarray(y_pred, dtype=np.float64)
    well_ids = np.asarray(well_ids)
    err = y_pred - y_true
    out = {
        "MAE": float(np.mean(np.abs(err))),
        "RMSE": float(np.sqrt(np.mean(err**2))),
        "R2": _r2(y_true, y_pred),
        "n": int(len(y_true)),
        "n_wells": int(len(np.unique(well_ids))),
    }
    r2s = []
    for wid in np.unique(well_ids):
        sel = well_ids == wid
        if sel.sum() < min_points:
            continue
        r = _r2(y_true[sel], y_pred[sel])
        if np.isfinite(r):
            r2s.append(r)
    out["R2_within_median"] = float(np.median(r2s)) if r2s else float("nan")
    out["R2_within_mean"] = float(np.mean(r2s)) if r2s else float("nan")
    out["within_well_r2"] = r2s
    return out


def per_well_table(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    well_ids: np.ndarray,
    well_names: list[str],
) -> pd.DataFrame:
    """逐井误差表，便于画图和报告。"""
    rows = []
    for wid in np.unique(well_ids):
        sel = well_ids == wid
        y, p = y_true[sel], y_pred[sel]
        if len(y) < 2:
            continue
        err = p - y
        rows.append(
            {
                "well": well_names[int(wid)],
                "n": int(sel.sum()),
                "MAE": float(np.mean(np.abs(err))),
                "RMSE": float(np.sqrt(np.mean(err**2))),
                "bias": float(np.mean(err)),
                "R2": _r2(y, p),
                "R2_within": _r2(y, p),
                "dtc_mean": float(np.mean(y)),
            }
        )
    return pd.DataFrame(rows).sort_values("R2").reset_index(drop=True)


def summarize_row(name: str, m: dict) -> dict:
    """整理成写表用的扁平字典。"""
    return {
        "模型": name,
        "MAE": round(m["MAE"], 3),
        "RMSE": round(m["RMSE"], 3),
        "整体R2": round(m["R2"], 4),
        "单井R2中位数": round(m["R2_within_median"], 4),
        "单井R2均值": round(m["R2_within_mean"], 4),
        "测试点数": m["n"],
        "测试井数": m["n_wells"],
    }
