﻿﻿﻿﻿﻿﻿﻿﻿# 一键复现：数据准备 -> 基线 -> GBDT 主模型 -> U-Net 对照 -> 参数实验 -> 图表 -> 示例
# 用法：powershell -ExecutionPolicy Bypass -File .\run_all.ps1
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$env:PYTHONIOENCODING = 'utf-8'
$env:PYTHONUNBUFFERED = '1'
$py = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'

function Step($name, $script, $argsList) {
    Write-Host "`n===== $name =====" -ForegroundColor Cyan
    $t0 = Get-Date
    & $py $script @argsList
    if ($LASTEXITCODE -ne 0) { throw "$name 失败（exit $LASTEXITCODE）" }
    Write-Host ("  用时 {0:N1} 分钟" -f ((Get-Date) - $t0).TotalMinutes) -ForegroundColor DarkGray
}

# 0. 环境检查
Write-Host "===== 环境检查 =====" -ForegroundColor Cyan
& $py -c "import torch; print('torch', torch.__version__, 'cuda', torch.cuda.is_available())"
if ($LASTEXITCODE -ne 0) { throw 'Python 环境不可用' }

# 1. 数据
Step '数据准备' 'src\data_prep.py' @()

# 2. 点预测基线
Step '线性回归（4 曲线，无深度）' 'src\train_point.py' @('--model','lr','--name','lr_core4_nodepth','--curves','core4','--no_depth')
Step 'MLP（4 曲线，无深度）'     'src\train_point.py' @('--model','mlp','--name','mlp_core4','--curves','core4','--no_depth','--epochs','25')
Step 'MLP（18 曲线+井内标准化+岩性）' 'src\train_point.py' @('--model','mlp','--name','mlp_all','--curves','all','--well_norm','--lith','--epochs','30')

# 3. GBDT
Step 'GBDT（4 曲线+深度）'       'src\train_gbdt.py' @('--name','gbdt_core4','--curves','core4','--max_iter','400')
Step 'GBDT（18 曲线+深度）'      'src\train_gbdt.py' @('--name','gbdt_l31','--curves','all','--max_iter','500','--lr','0.05','--leaves','31')
Step 'GBDT（31 叶子 + 岩性，主模型）' 'src\train_gbdt.py' @('--name','gbdt_l31_lith','--curves','all','--lith','--max_iter','500','--lr','0.05','--leaves','31')
Step 'GBDT（18 曲线+深度+岩性）' 'src\train_gbdt.py' @('--name','gbdt_all','--curves','all','--lith','--max_iter','500','--lr','0.05')

# 4. U-Net
Step '1D U-Net 序列模型' 'src\train_unet.py' @('--name','unet_w48','--curves','all','--width','48','--epochs','10','--steps','800','--val_wells','0')

# 5. 参数实验与图表
Step '参数敏感性实验' 'src\param_sweep.py' @()
Step '曲线消融'        'src\feature_ablation.py' @()
Step '跨象限泛化'      'src\cross_quadrant.py' @()
Step '生成图表'        'src\plots.py' @()

# 6. 单井示例
Step '单井示例预测' 'src\predict.py' @('--model','outputs\models\gbdt_l31_lith.joblib','--las','data\las\31_2-19 S.las','--out','示例\31_2-19S_DTC预测')

Write-Host "`n全部完成！" -ForegroundColor Green
Write-Host "结果在 outputs\ 下，汇报 PPT 在 报告\ 下。" -ForegroundColor Green
