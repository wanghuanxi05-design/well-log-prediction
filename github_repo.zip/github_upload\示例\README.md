# 单井预测示例

本目录是 `src/predict.py` 生成的示例，用最终 GBDT 单模型（`outputs/models/gbdt_l31_lith.joblib`）预测测试井 **31/2-19 S** 的 DTC。

- `31_2-19S_DTC预测.csv`：逐采样点结果
  - `DEPTH_MD`：深度（m）
  - `DTC_pred`：预测声波时差（μs/ft）
  - `DTC_true`：实测 DTC（仅演示数据有）
  - `residual`：预测 − 实测
- `31_2-19S_DTC预测.png`：GR / RHOB-NPHI / DTC / 残差 四道图

## 指标

| 项目 | 数值 |
|---|---|
| 采样点 | 24,730 |
| 曲线覆盖率 | 64.9% |
| 与实测对比 | MAE 6.75 μs/ft，RMSE 8.86，R² 0.872 |

该井未参与训练，属于 29 口测试井之一。

## 复现

```powershell
cd D:\人工智能大作业
$env:PYTHONIOENCODING = 'utf-8'
& .\.venv\Scripts\python.exe src\predict.py `
    --model outputs\models\gbdt_l31_lith.joblib `
    --las "data\las\31_2-19 S.las" `
    --out "示例\31_2-19S_DTC预测"
```

也可以换成任意一口 LAS：

```powershell
& .\.venv\Scripts\python.exe src\predict.py --las "data\las\29_6-1.las" --out "示例\29_6-1_DTC预测"
```
