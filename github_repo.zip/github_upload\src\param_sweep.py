r"""参数敏感性实验：在「验证井」上比较不同超参数，为汇报提供真实依据。

为什么单独做：
    最终测试集只能用于最后报告，不能拿来调参。这里从 69 口训练井中按象限分层
    留出 9 口做验证井（不参与训练），在验证井上比较 U-Net / GBDT / MLP 的参数，
    选出的最优配置再用于最终模型（最终模型仍用全部 69 口训练井重训）。

运行：
    .\.venv\Scripts\python.exe src\param_sweep.py
    .\.venv\Scripts\python.exe src\param_sweep.py --only unet
"""
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from sklearn.ensemble import HistGradientBoostingRegressor

import config as C
from data_prep import load_cache
from evaluation import compute_metrics
from models import MLP, UNet1D, count_params
from seq_data import SeqData, predict_well
from train_point import build_X

OUT_CSV = C.OUT_TAB / "param_sweep.csv"
OUT_JSON = C.OUT_TAB / "param_sweep.json"
N_VAL = 9
SWEEP_SEED = 2026


# --------------------------------------------------------------------------
def pick_val_wells(data) -> list[int]:
    """按象限分层，从训练井中留 9 口，保证覆盖不同区域。"""
    names = list(data["well_names"])
    wid = data["well_id"]
    is_test = data["is_test"].astype(bool)
    real_test = set(np.unique(wid[is_test]).tolist())
    train = [i for i in range(len(names)) if i not in real_test]
    by_quad: dict[str, list[int]] = {}
    for i in train:
        q = str(names[i]).split("/")[0]
        by_quad.setdefault(q, []).append(i)
    rng = np.random.RandomState(SWEEP_SEED)
    quads = sorted(by_quad)
    rng.shuffle(quads)
    chosen = [int(rng.choice(by_quad[q])) for q in quads[:N_VAL]]
    return sorted(chosen)


def collect_metrics(y, p, w):
    m = compute_metrics(np.asarray(y), np.asarray(p), np.asarray(w))
    return {"MAE": round(m["MAE"], 3), "R2": round(m["R2"], 4),
            "单井R2": round(m["R2_within_median"], 4), "点数": m["n"], "井数": m["n_wells"]}


# --------------------------------------------------------------------------
# U-Net
# --------------------------------------------------------------------------
def run_unet(data, meta, val_wids, cfg, device, epochs=8, steps=700):
    data2 = dict(data)
    is_test2 = data["is_test"].astype(bool).copy()
    is_test2[np.isin(data["well_id"], val_wids)] = True
    data2["is_test"] = is_test2.astype(np.int8)

    seq = SeqData(data2, list(C.CURVES), use_well_norm=True, use_lith=False, n_val=0)
    val_seq = [w for w in seq.test if w["wid"] in set(val_wids)]
    C.seed_everything(C.SEED)
    model = UNet1D(seq.n_channels, width=cfg["width"], depth=cfg["depth"], dropout=cfg.get("dropout", 0.0)).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=cfg["lr"], weight_decay=1e-4)
    total = epochs * steps
    sched = torch.optim.lr_scheduler.OneCycleLR(opt, max_lr=cfg["lr"], total_steps=total,
                                                pct_start=0.15, div_factor=10, final_div_factor=50)
    scaler = torch.amp.GradScaler("cuda", enabled=device.type == "cuda")
    loss_fn = nn.SmoothL1Loss(beta=1.0)
    rng = np.random.default_rng(C.SEED)
    t0 = time.time()
    for ep in range(1, epochs + 1):
        model.train()
        for _ in range(steps):
            xb, yb, _ = seq.sample_batch(rng, 32, cfg["length"])
            x = torch.from_numpy(xb).to(device, non_blocking=True)
            y = torch.from_numpy(yb).to(device, non_blocking=True)
            with torch.autocast("cuda", dtype=torch.float16, enabled=device.type == "cuda"):
                out = model(x)
                loss = loss_fn(out[:, 0, :], y)
            opt.zero_grad(set_to_none=True)
            scaler.scale(loss).backward()
            scaler.unscale_(opt)
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            scaler.step(opt)
            scaler.update()
            sched.step()
    train_s = time.time() - t0

    model.eval()
    ys, ps, ws = [], [], []
    for w in val_seq:
        pz = predict_well(model, w, cfg["length"], 64, device)
        ys.append(w["y_raw"])
        ps.append(pz * meta["target_scale"] + meta["target_median"])
        ws.append(np.full(w["n"], w["wid"]))
    met = collect_metrics(np.concatenate(ys), np.concatenate(ps), np.concatenate(ws))
    return met, count_params(model) / 1e6, train_s


# --------------------------------------------------------------------------
# GBDT
# --------------------------------------------------------------------------
def run_gbdt(data, val_wids, cfg):
    X, _ = build_X(data, list(C.CURVES), False, False, True)
    y = data["target"]
    wid = data["well_id"]
    tr = ~np.isin(wid, val_wids)
    va = np.isin(wid, val_wids)
    model = HistGradientBoostingRegressor(
        max_iter=cfg["iter"], learning_rate=cfg["lr"], max_leaf_nodes=cfg["leaves"],
        min_samples_leaf=50, l2_regularization=1.0, early_stopping=False,
        random_state=C.SEED,
    )
    t0 = time.time()
    model.fit(X[tr], y[tr])
    met = collect_metrics(y[va], model.predict(X[va]), wid[va])
    return met, time.time() - t0


# --------------------------------------------------------------------------
# MLP
# --------------------------------------------------------------------------
def run_mlp(data, meta, val_wids, cfg, device, epochs=20):
    X, _ = build_X(data, list(C.CURVES), False, False, True)
    y = data["target_z"].astype(np.float32)
    wid = data["well_id"]
    tr = np.where(~np.isin(wid, val_wids))[0]
    va = np.where(np.isin(wid, val_wids))[0]
    C.seed_everything(C.SEED)
    model = MLP(X.shape[1], tuple(cfg["hidden"]), dropout=0.1).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=1e-3, weight_decay=1e-4)
    steps = (len(tr) + 4095) // 4096
    sched = torch.optim.lr_scheduler.OneCycleLR(opt, max_lr=1e-3, total_steps=epochs * steps, pct_start=0.2)
    scaler = torch.amp.GradScaler("cuda", enabled=device.type == "cuda")
    loss_fn = nn.SmoothL1Loss(beta=1.0)
    Xt = torch.from_numpy(X[tr]).to(device)
    yt = torch.from_numpy(y[tr]).to(device)
    Xv = torch.from_numpy(X[va]).to(device)
    yv = torch.from_numpy(y[va]).to(device)
    rng = np.random.default_rng(C.SEED)
    t0 = time.time()
    best, best_state, bad = float("inf"), None, 0
    for ep in range(epochs):
        model.train()
        perm = rng.permutation(len(tr))
        for i in range(0, len(tr), 4096):
            sel = torch.from_numpy(perm[i:i + 4096]).to(device)
            with torch.autocast("cuda", dtype=torch.float16, enabled=device.type == "cuda"):
                loss = loss_fn(model(Xt[sel]), yt[sel])
            opt.zero_grad(set_to_none=True)
            scaler.scale(loss).backward()
            scaler.step(opt)
            scaler.update()
            sched.step()
        model.eval()
        with torch.no_grad(), torch.autocast("cuda", dtype=torch.float16, enabled=device.type == "cuda"):
            vloss = float(loss_fn(model(Xv), yv))
        if vloss < best - 1e-5:
            best, bad = vloss, 0
            best_state = {k: v.detach().clone() for k, v in model.state_dict().items()}
        else:
            bad += 1
            if bad >= 4:
                break
    model.load_state_dict(best_state)
    model.eval()
    with torch.no_grad(), torch.autocast("cuda", dtype=torch.float16, enabled=device.type == "cuda"):
        pz = model(Xv).float().cpu().numpy()
    pred = pz * meta["target_scale"] + meta["target_median"]
    met = collect_metrics(data["target"][va], pred, wid[va])
    return met, count_params(model) / 1e6, time.time() - t0


# --------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", choices=["unet", "gbdt", "mlp"], default=None)
    args = ap.parse_args()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    data, meta = load_cache()
    val_wids = pick_val_wells(data)
    names = list(data["well_names"])
    print("验证井（9 口，不参与训练）：", [names[i] for i in val_wids])

    rows = []
    if args.only in (None, "unet"):
        configs = [
            dict(tag="Unet-宽度16", width=16, depth=4, length=256, lr=1e-3),
            dict(tag="Unet-宽度32", width=32, depth=4, length=256, lr=1e-3),
            dict(tag="Unet-宽度48", width=48, depth=4, length=256, lr=1e-3),
            dict(tag="Unet-深度3", width=32, depth=3, length=256, lr=1e-3),
            dict(tag="Unet-深度5", width=32, depth=5, length=256, lr=1e-3),
            dict(tag="Unet-窗口128", width=32, depth=4, length=128, lr=1e-3),
            dict(tag="Unet-窗口512", width=32, depth=4, length=512, lr=1e-3),
            dict(tag="Unet-lr5e-4", width=32, depth=4, length=256, lr=5e-4),
            dict(tag="Unet-lr2e-3", width=32, depth=4, length=256, lr=2e-3),
        ]
        for cfg in configs:
            met, pm, ts = run_unet(data, meta, val_wids, cfg, device)
            rows.append({"模型": "U-Net", "配置": cfg["tag"], "宽度": cfg["width"], "深度": cfg["depth"],
                         "窗口": cfg["length"], "学习率": cfg["lr"], "参数量M": round(pm, 2),
                         **met, "用时s": round(ts, 1)})
            print(f"{cfg['tag']:14s} R2={met['R2']:.4f} 单井={met['单井R2']:.4f} MAE={met['MAE']:.2f} "
                  f"params={pm:.2f}M {ts:.0f}s")

    if args.only in (None, "gbdt"):
        configs = [
            dict(tag="GBDT-叶子31", leaves=31, iter=500, lr=0.05),
            dict(tag="GBDT-叶子63", leaves=63, iter=500, lr=0.05),
            dict(tag="GBDT-叶子127", leaves=127, iter=500, lr=0.05),
            dict(tag="GBDT-迭代200", leaves=63, iter=200, lr=0.05),
            dict(tag="GBDT-迭代800", leaves=63, iter=800, lr=0.05),
            dict(tag="GBDT-lr0.03", leaves=63, iter=500, lr=0.03),
            dict(tag="GBDT-lr0.10", leaves=63, iter=500, lr=0.10),
        ]
        for cfg in configs:
            met, ts = run_gbdt(data, val_wids, cfg)
            rows.append({"模型": "GBDT", "配置": cfg["tag"], "叶子数": cfg["leaves"], "迭代": cfg["iter"],
                         "学习率": cfg["lr"], **met, "用时s": round(ts, 1)})
            print(f"{cfg['tag']:14s} R2={met['R2']:.4f} 单井={met['单井R2']:.4f} MAE={met['MAE']:.2f} {ts:.0f}s")

    if args.only in (None, "mlp"):
        configs = [dict(tag="MLP-64", hidden=[64, 64]), dict(tag="MLP-128", hidden=[128, 128]),
                   dict(tag="MLP-256", hidden=[256, 256, 128])]
        for cfg in configs:
            met, pm, ts = run_mlp(data, meta, val_wids, cfg, device)
            rows.append({"模型": "MLP", "配置": cfg["tag"], "隐藏层": "-".join(map(str, cfg["hidden"])),
                         "参数量M": round(pm, 2), **met, "用时s": round(ts, 1)})
            print(f"{cfg['tag']:14s} R2={met['R2']:.4f} 单井={met['单井R2']:.4f} MAE={met['MAE']:.2f} {ts:.0f}s")

    df = pd.DataFrame(rows)
    old = pd.read_csv(OUT_CSV) if OUT_CSV.exists() else None
    if old is not None and args.only:
        df = pd.concat([old[~old["配置"].isin(df["配置"])], df], ignore_index=True)
    df.to_csv(OUT_CSV, index=False, encoding="utf-8-sig")
    best = {}
    for model in df["模型"].unique():
        sub = df[df["模型"] == model]
        best[model] = sub.sort_values("单井R2", ascending=False).iloc[0].to_dict()
    OUT_JSON.write_text(json.dumps({
        "val_wells": [names[i] for i in val_wids],
        "best": {k: {kk: (vv.item() if hasattr(vv, "item") else vv) for kk, vv in v.items()} for k, v in best.items()},
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    print("\n最优配置：")
    for k, v in best.items():
        print(k, v["配置"], "R2=", v["R2"], "单井R2=", v["单井R2"], "MAE=", v["MAE"])


if __name__ == "__main__":
    main()
