r"""跨象限泛化实验：留一个象限做测试，检验模型换区域还能不能用。

做法：
    对每个大象限（34/35/25/16/31），用其它象限的所有井训练，预测该象限；
    再模拟「现场有 5% 实测 DTC」的情形，用这 5% 点估计每口井的偏置并校正。

输出：
    outputs/tables/cross_quadrant.csv
    outputs/figures/fig_cross_quadrant.png
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor

import config as C
from data_prep import load_cache
from evaluation import compute_metrics

QUADS = ["34", "35", "25", "16", "31"]


def build_X(data):
    X = np.hstack([
        data["x_global"], data["mask"], data["depth_z"].reshape(-1, 1),
    ]).astype(np.float32)
    return X


def calibrate(y, pred, well_id, frac=0.05, seed=C.SEED):
    """每口井随机取 frac 的实测点估计平均残差，再从全部预测中减掉。"""
    rng = np.random.RandomState(seed)
    out = pred.copy()
    for wid in np.unique(well_id):
        idx = np.where(well_id == wid)[0]
        k = max(1, int(len(idx) * frac))
        pick = rng.choice(idx, size=k, replace=False)
        bias = float(np.mean(y[pick] - pred[pick]))
        out[idx] += bias
    return out


def main():
    data, meta = load_cache()
    X = build_X(data)
    y = data["target"]
    well_id = data["well_id"]
    names = np.array(data["well_names"])
    quad = np.array([str(n).split("/")[0] for n in names])
    rows = []

    for q in QUADS:
        test_wells = np.where(quad == q)[0]
        tr = np.where(~np.isin(well_id, test_wells))[0]
        te = np.where(np.isin(well_id, test_wells))[0]
        model = HistGradientBoostingRegressor(
            max_iter=300, learning_rate=0.06, max_leaf_nodes=63,
            min_samples_leaf=50, l2_regularization=1.0,
            early_stopping=False, random_state=C.SEED,
        )
        model.fit(X[tr], y[tr])
        pred = model.predict(X[te])
        m0 = compute_metrics(y[te], pred, well_id[te])
        pred_c = calibrate(y[te], pred, well_id[te])
        m1 = compute_metrics(y[te], pred_c, well_id[te])
        rows.append({
            "象限": q, "测试井数": len(test_wells), "测试点数": len(te),
            "零样本整体R2": round(m0["R2"], 4), "零样本单井R2": round(m0["R2_within_median"], 4),
            "零样本MAE": round(m0["MAE"], 3),
            "5%校正整体R2": round(m1["R2"], 4), "5%校正单井R2": round(m1["R2_within_median"], 4),
            "5%校正MAE": round(m1["MAE"], 3),
        })
        print(rows[-1])

    df = pd.DataFrame(rows)
    df.to_csv(C.OUT_TAB / "cross_quadrant.csv", index=False, encoding="utf-8-sig")

    C.setup_matplotlib()
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(6.8, 3.8), dpi=200)
    x = np.arange(len(df))
    ax.bar(x - 0.2, df["零样本单井R2"], 0.38, label="零样本", color="#4c72b0")
    ax.bar(x + 0.2, df["5%校正单井R2"], 0.38, label="5% 实测点校正后", color="#55a868")
    for xi, v in zip(x - 0.2, df["零样本单井R2"]):
        ax.text(xi, v + 0.01, f"{v:.3f}", ha="center", fontsize=8)
    for xi, v in zip(x + 0.2, df["5%校正单井R2"]):
        ax.text(xi, v + 0.01, f"{v:.3f}", ha="center", fontsize=8)
    ax.set_xticks(x)
    ax.set_xticklabels([f"留出 {q}" for q in df["象限"]])
    ax.set_ylim(0.5, 1.0)
    ax.set_ylabel("单井内 R2 中位数")
    ax.set_title("跨象限泛化：留一象限测试")
    ax.grid(axis="y", alpha=0.3)
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(C.OUT_FIG / "fig_cross_quadrant.png", bbox_inches="tight")
    plt.close(fig)
    print("已保存 cross_quadrant.csv / fig_cross_quadrant.png")


if __name__ == "__main__":
    main()
