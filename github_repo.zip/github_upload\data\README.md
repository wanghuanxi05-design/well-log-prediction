# 数据放置说明

仓库不包含 FORCE 2020 原始数据，请自行下载后按下面结构放置。

## 1. FORCE 2020 训练表

下载 FORCE 2020 Well Log Dataset：

- Zenodo：<https://doi.org/10.5281/zenodo.4351155>
- 找到 `train.csv`，放到：

```
data/raw/train.csv
```

要求：

- 分号分隔（`sep=";"`），不是逗号；
- 至少包含 `WELL`、`DEPTH_MD`、`DTC`、`GR` 以及 18 条候选曲线中的其它列；
- 含岩性的模型还需要 `FORCE_2020_LITHOFACIES_LITHOLOGY` 列。

首次运行数据准备会生成：

```
data/processed/dataset.npz
data/processed/meta.json
```

这两个文件是缓存，不需要上传。

## 2. 单井 LAS（可选）

示例和 Streamlit 的“示例井”需要：

```
data/las/*.las
```

例如：

```
data/las/31_2-19 S.las
```

没有 LAS 也可以直接上传 LAS 文件做预测；`predict.py` 支持 `--las` 路径。

## 3. 为什么不上传数据

- `train.csv` 约 267 MB，超过 GitHub 普通仓库的舒适范围；
- `dataset.npz` 约 96 MB，可由 `src/data_prep.py` 重新生成；
- 原始数据版权归 FORCE 2020 作者，请遵守其许可协议。

代码只读取上述相对路径，不依赖本机绝对路径。
