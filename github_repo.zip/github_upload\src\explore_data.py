r"""数据探索：统计曲线覆盖、井/深度分布、岩性类别、缺失规律与相关性。

运行：
    .\.venv\Scripts\python.exe src\explore_data.py
输出：
    outputs/tables/data_overview.json
    outputs/tables/lithology_counts.csv
    outputs/figures/data_coverage.png
"""
from __future__ import annotations

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw" / "train.csv"
OUT_T = ROOT / "outputs" / "tables"
OUT_F = ROOT / "outputs" / "figures"
OUT_T.mkdir(parents=True, exist_ok=True)
OUT_F.mkdir(parents=True, exist_ok=True)

# FORCE 2020 岩性编码 -> 名称（竞赛官方 12 类岩性定义）
LITH_NAME = {
    30000: "砂岩 Sandstone",
    65030: "砂页岩互层 Sandstone/Shale",
    65000: "页岩 Shale",
    80000: "泥灰岩 Marl",
    74000: "白云岩 Dolomite",
    70000: "石灰岩 Limestone",
    70032: "白垩 Chalk",
    88000: "盐岩 Halite",
    86000: "硬石膏 Anhydrite",
    99000: "基底 Basement",
    90000: "煤 Coal",
    93000: "凝灰岩 Tuff",
}

CURVES = ["GR", "RHOB", "NPHI", "RDEP", "CALI", "SP", "PEF", "DTC", "DTS", "RMED"]


def main() -> None:
    df = pd.read_csv(RAW, sep=";")
    n, nw = len(df), df["WELL"].nunique()
    print(f"行数={n:,}  井数={nw}  列数={df.shape[1]}")

    # ---------- 1. 覆盖率 ----------
    cov = (df[CURVES].notna().mean() * 100).round(1)
    print("\n== 曲线覆盖率(%) ==\n", cov.to_string())

    # ---------- 2. 关键组合行数 ----------
    combos = {
        "GR+RHOB+NPHI+RDEP": ["GR", "RHOB", "NPHI", "RDEP"],
        "+CALI": ["GR", "RHOB", "NPHI", "RDEP", "CALI"],
        "+SP": ["GR", "RHOB", "NPHI", "RDEP", "SP"],
        "+PEF": ["GR", "RHOB", "NPHI", "RDEP", "PEF"],
        "+CALI+SP+PEF": ["GR", "RHOB", "NPHI", "RDEP", "CALI", "SP", "PEF"],
        "无NPHI(GR+RHOB+RDEP)": ["GR", "RHOB", "RDEP"],
        "无NPHI+CALI": ["GR", "RHOB", "RDEP", "CALI"],
    }
    combo_stat = {}
    for name, cols in combos.items():
        m = df[cols].notna().all(axis=1)
        combo_stat[name] = {
            "rows": int(m.sum()),
            "pct": round(float(m.mean() * 100), 1),
            "wells": int(df.loc[m, "WELL"].nunique()),
        }
    print("\n== 输入组合 ==")
    print(pd.DataFrame(combo_stat).T.to_string())

    # ---------- 3. 井/深度 ----------
    depth_stats = df.groupby("WELL")["DEPTH_MD"].agg(["min", "max", "count"])
    # 采样间隔（按井内相邻深度差的中位数）
    step = df.sort_values(["WELL", "DEPTH_MD"]).groupby("WELL")["DEPTH_MD"].diff().dropna()
    step = step[(step > 0) & (step < 5)]
    print(f"\n深度范围 {df.DEPTH_MD.min():.1f} ~ {df.DEPTH_MD.max():.1f} m")
    print(f"井段长度 {depth_stats['max'].sub(depth_stats['min']).min():.0f} ~ "
          f"{depth_stats['max'].sub(depth_stats['min']).max():.0f} m")
    print(f"采样间隔中位数={step.median():.4f} m, 90分位={step.quantile(0.9):.4f} m")

    # ---------- 4. 岩性 ----------
    lith = df["FORCE_2020_LITHOFACIES_LITHOLOGY"]
    lith_counts = lith.value_counts().rename_axis("code").reset_index(name="rows")
    lith_counts["name"] = lith_counts["code"].map(LITH_NAME).fillna("其他/未知")
    lith_counts["pct"] = (lith_counts["rows"] / n * 100).round(2)
    print("\n== 岩性 ==")
    print(lith_counts.to_string(index=False))
    lith_counts.to_csv(OUT_T / "lithology_counts.csv", index=False, encoding="utf-8-sig")

    # ---------- 5. 缺失规律 ----------
    # NPHI 缺失时 DTC 还在吗？这决定“加掩码”的价值
    miss = {}
    for c in ["NPHI", "SP", "PEF", "CALI", "RHOB"]:
        m = df[c].isna()
        miss[c] = {
            "缺失行数": int(m.sum()),
            "缺失时DTC仍存在比例": round(float(df.loc[m, "DTC"].notna().mean() * 100), 1),
            "缺失时GR仍存在比例": round(float(df.loc[m, "GR"].notna().mean() * 100), 1),
        }
    print("\n== 缺失规律 ==")
    print(pd.DataFrame(miss).T.to_string())

    # ---------- 6. 相关性 ----------
    valid = df[["DTC"] + [c for c in CURVES if c != "DTC"]].dropna()
    corr = valid.corr(numeric_only=True)["DTC"].drop("DTC").sort_values(ascending=True)
    print(f"\n== 与 DTC 的皮尔逊相关（完整行 {len(valid):,}）==\n", corr.round(3).to_string())

    # ---------- 7. 井间 vs 井内方差 ----------
    dtc_well = df.dropna(subset=["DTC"]).groupby("WELL")["DTC"]
    overall_std = df["DTC"].std()
    within_std = dtc_well.std().median()
    print(f"\nDTC 总体标准差={overall_std:.2f}, 井内标准差中位数={within_std:.2f}, "
          f"井间中位数极差={dtc_well.median().max() - dtc_well.median().min():.2f}")

    # ---------- 8. 坐标 ----------
    print(f"X {df.X_LOC.min():.0f}~{df.X_LOC.max():.0f}, Y {df.Y_LOC.min():.0f}~{df.Y_LOC.max():.0f}")
    quad = df["WELL"].str.split("/").str[0]
    print("象限分布:", quad.nunique(), "个; 井数:", quad.value_counts().to_dict())

    # ---------- 8.5 分位数（用于定物理过滤范围） ----------
    q = df[["GR", "RHOB", "NPHI", "RDEP", "DTC", "CALI", "SP", "PEF"]].quantile(
        [0.001, 0.01, 0.5, 0.99, 0.999]
    )
    print("\n== 分位数 ==")
    print(q.round(3).to_string())

    # ---------- 9. 存 JSON ----------
    summary = {
        "rows": int(n),
        "wells": int(nw),
        "columns": df.columns.tolist(),
        "coverage_pct": cov.to_dict(),
        "combos": combo_stat,
        "depth": {
            "min": float(df.DEPTH_MD.min()),
            "max": float(df.DEPTH_MD.max()),
            "median_step_m": float(step.median()),
            "p90_step_m": float(step.quantile(0.9)),
        },
        "lithology": lith_counts.to_dict(orient="records"),
        "missing": miss,
        "corr_with_dtc": corr.round(4).to_dict(),
        "dtc_std_overall": float(overall_std),
        "dtc_std_within_well_median": float(within_std),
        "dtc_well_median_range": float(dtc_well.median().max() - dtc_well.median().min()),
        "quadrants": int(quad.nunique()),
    }
    with open(OUT_T / "data_overview.json", "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)

    # ---------- 10. 覆盖率图 ----------
    fig, ax = plt.subplots(figsize=(7.2, 4.0), dpi=150)
    order = cov.sort_values(ascending=True)
    colors = ["#c44e52" if c == "DTC" else "#4c72b0" for c in order.index]
    ax.barh(order.index, order.values, color=colors)
    for i, v in enumerate(order.values):
        ax.text(v + 1, i, f"{v:.1f}%", va="center", fontsize=8)
    ax.set_xlim(0, 110)
    ax.set_xlabel("覆盖率 (%)")
    ax.set_title("FORCE 2020 训练集曲线覆盖率（98 口井，117 万行）")
    ax.grid(axis="x", alpha=0.3)
    fig.tight_layout()
    fig.savefig(OUT_F / "data_coverage.png")
    plt.close(fig)
    print(f"\n已保存 {OUT_T/'data_overview.json'} 与 {OUT_F/'data_coverage.png'}")


if __name__ == "__main__":
    main()
