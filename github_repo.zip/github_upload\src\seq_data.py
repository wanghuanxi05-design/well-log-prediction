"""序列数据：把每口井的采样点组织成连续数组，供 1D U-Net 使用。

关键点
    - 输入通道 = 全局标准化曲线 + 缺失掩码 + 井内标准化曲线 + 深度 + 相对深度
    - 缺失值填 0（即中位数），由掩码通道告诉网络“这里原本没有值”
    - 井与井之间互不拼接，窗口不会跨井
"""
from __future__ import annotations

import numpy as np

import config as C

PAD = 256  # 每口井两端复制填充的长度，足够覆盖任意窗口


class SeqData:
    """按井存放的连续数组。"""

    def __init__(self, data: dict, curves: list[str], use_well_norm: bool = True,
                 use_lith: bool = False, n_val: int = 3):
        self.curves = curves
        self.use_lith = use_lith
        idx = [C.CURVES.index(c) for c in curves]
        names = list(data["well_names"])
        offsets = data["offsets"]
        is_test = data["is_test"].astype(bool)
        depth_m = data["depth_m"]

        self.wells: list[dict] = []
        for wid in range(len(names)):
            s, e = int(offsets[wid]), int(offsets[wid + 1])
            if e <= s:
                continue
            parts = [data["x_global"][s:e][:, idx], data["mask"][s:e][:, idx]]
            if use_well_norm:
                parts.append(data["x_well"][s:e][:, idx])
            d = depth_m[s:e]
            dmin, dmax = float(d.min()), float(d.max())
            rel = (d - dmin) / max(dmax - dmin, 1e-6)
            parts += [data["depth_z"][s:e].reshape(-1, 1), rel.reshape(-1, 1).astype(np.float32)]
            x = np.hstack(parts).astype(np.float32)

            # 两端复制填充，窗口越界时取边缘值
            xp = np.pad(x, ((PAD, PAD), (0, 0)), mode="edge")
            item = {
                "wid": wid,
                "name": names[wid],
                "is_test": bool(is_test[s]),
                "x": xp,
                "n": e - s,
                "y": data["target_z"][s:e].copy(),
                "y_raw": data["target"][s:e].copy(),
                "depth": d.copy(),
            }
            if use_lith:
                item["lith"] = data["lith"][s:e].copy()
            self.wells.append(item)

        self.curve_names = curves
        self.n_channels = self.wells[0]["x"].shape[1]
        all_train = [w for w in self.wells if not w["is_test"]]
        self.test = [w for w in self.wells if w["is_test"]]
        # 从训练井中再留出少量井做验证（早停用），测试井全程不参与任何选择
        # n_val=0 表示用全部训练井、固定 epoch 训练（不再早停）
        rng = np.random.RandomState(C.SEED)
        n_val = max(0, min(6, n_val))
        val_idx = set(rng.choice(len(all_train), size=n_val, replace=False).tolist()) if n_val else set()
        self.train = [w for i, w in enumerate(all_train) if i not in val_idx]
        self.val = [w for i, w in enumerate(all_train) if i in val_idx]
        # 按井长加权采样；只从训练井采样（严格按井划分，防止泄漏）
        lens = np.array([w["n"] for w in self.train], dtype=np.float64)
        self._p = lens / lens.sum()

    def sample_batch(self, rng: np.random.Generator, batch: int, length: int):
        """随机取 batch 个窗口。返回 x(B,C,L), y(B,L), lith(B,L) 或 None。"""
        picks = rng.choice(len(self.train), size=batch, p=self._p)
        xs = np.empty((batch, self.n_channels, length), dtype=np.float32)
        ys = np.empty((batch, length), dtype=np.float32)
        ls = np.empty((batch, length), dtype=np.uint8) if self.use_lith else None
        for i, idx in enumerate(picks):
            w = self.train[int(idx)]
            n = w["n"]
            half = length // 2
            c = int(rng.integers(half, n - half)) if n > length else n // 2
            start = c - half
            xs[i] = w["x"][start + PAD:start + PAD + length].T
            ys[i] = w["y"][start:start + length]
            if ls is not None:
                ls[i] = w["lith"][start:start + length]
        return xs, ys, ls

    def val_windows(self, length: int, n_per_well: int = 12):
        """固定验证窗口（每口验证井均匀取 n_per_well 个），用于早停。"""
        xs, ys, ls = [], [], []
        for w in self.val:
            half = length // 2
            centers = np.linspace(half, max(half, w["n"] - half - 1), n_per_well).astype(int)
            for c in centers:
                s = c - half
                xs.append(w["x"][s + PAD: s + PAD + length].T)
                ys.append(w["y"][s: s + length])
                if self.use_lith:
                    ls.append(w["lith"][s: s + length])
        x = np.stack(xs).astype(np.float32)
        y = np.stack(ys).astype(np.float32)
        lith = np.stack(ls).astype(np.uint8) if self.use_lith else None
        return x, y, lith


def predict_well(model, well: dict, length: int, stride: int, device, batch_size: int = 256, use_amp: bool = True):
    """滑窗预测一整口井，重叠部分取平均；返回原始单位的预测。"""
    import torch

    n = well["n"]
    starts = list(range(0, max(n - length, 0) + 1, stride))
    if starts[-1] + length < n:
        starts.append(n - length)
    preds = np.zeros(n + 2 * PAD, dtype=np.float64)
    counts = np.zeros(n + 2 * PAD, dtype=np.float64)
    model.eval()
    with torch.no_grad():
        for i in range(0, len(starts), batch_size):
            chunk = starts[i:i + batch_size]
            xb = np.stack([well["x"][s + PAD:s + PAD + length].T for s in chunk]).astype(np.float32)
            xb = torch.from_numpy(xb).to(device)
            lb = None
            if getattr(model, "lith_emb", None) is not None and "lith" in well:
                lb = torch.from_numpy(
                    np.stack([well["lith"][s:s + length] for s in chunk]).astype(np.int64)
                ).to(device)
            if use_amp and device.type == "cuda":
                with torch.autocast("cuda", dtype=torch.float16):
                    out = model(xb, lb)
            else:
                out = model(xb, lb)
            out = out.float().cpu().numpy()[:, 0, :]
            for j, s in enumerate(chunk):
                preds[s + PAD:s + PAD + length] += out[j]
                counts[s + PAD:s + PAD + length] += 1
    preds = preds[PAD:PAD + n] / np.maximum(counts[PAD:PAD + n], 1)
    return preds
