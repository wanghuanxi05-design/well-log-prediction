"""模型定义：点预测 MLP、1D-CNN、序列 1D U-Net。

对应课件：
    - MLP + BP           -> 课件 13《4-MLP_BP》
    - 1D-CNN / LeNet5    -> 课件 5《7-LeNet5》、6《6-basic_conv》
    - U-Net（全卷积）     -> 课件 3.4《深度学习》中的卷积网络扩展
"""
from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F


# --------------------------------------------------------------------------
# 点预测模型
# --------------------------------------------------------------------------
class MLP(nn.Module):
    """逐点 MLP：输入一条采样点的多曲线特征，输出 DTC。"""

    def __init__(self, in_dim: int, hidden: tuple[int, ...] = (256, 256, 128), dropout: float = 0.1):
        super().__init__()
        layers: list[nn.Module] = []
        prev = in_dim
        for h in hidden:
            layers += [nn.Linear(prev, h), nn.BatchNorm1d(h), nn.ReLU(), nn.Dropout(dropout)]
            prev = h
        layers.append(nn.Linear(prev, 1))
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return self.net(x).squeeze(-1)


class CNN1D(nn.Module):
    """LeNet 风格的 1D-CNN：输入一小段深度窗口，输出中心点。"""

    def __init__(self, in_channels: int, width: int = 32, dropout: float = 0.1):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv1d(in_channels, width, 3, padding=1), nn.BatchNorm1d(width), nn.ReLU(),
            nn.Conv1d(width, width * 2, 3, padding=1), nn.BatchNorm1d(width * 2), nn.ReLU(),
            nn.MaxPool1d(2),
            nn.Conv1d(width * 2, width * 4, 3, padding=1), nn.BatchNorm1d(width * 4), nn.ReLU(),
            nn.AdaptiveAvgPool1d(1),
        )
        self.head = nn.Sequential(
            nn.Flatten(), nn.Linear(width * 4, 128), nn.ReLU(), nn.Dropout(dropout), nn.Linear(128, 1)
        )

    def forward(self, x):
        return self.head(self.features(x)).squeeze(-1)


# --------------------------------------------------------------------------
# 序列模型
# --------------------------------------------------------------------------
class ConvBlock(nn.Module):
    def __init__(self, cin: int, cout: int, k: int = 5, dropout: float = 0.0):
        super().__init__()
        layers = [
            nn.Conv1d(cin, cout, k, padding=k // 2), nn.BatchNorm1d(cout), nn.ReLU(inplace=True),
            nn.Conv1d(cout, cout, k, padding=k // 2), nn.BatchNorm1d(cout), nn.ReLU(inplace=True),
        ]
        if dropout > 0:
            layers.append(nn.Dropout(dropout))
        self.block = nn.Sequential(*layers)

    def forward(self, x):
        return self.block(x)


class UNet1D(nn.Module):
    """1D U-Net：输入一段 256 点的多曲线序列，输出同长度的 DTC 序列。

    相比逐点 MLP，它能同时利用上下文的层序、趋势和曲线形态；
    相比普通 CNN 分类式池化，它不丢失深度分辨率。
    """

    def __init__(
        self,
        in_channels: int,
        width: int = 32,
        depth: int = 4,
        lith_classes: int = 0,
        lith_dim: int = 8,
        dropout: float = 0.0,
    ):
        super().__init__()
        self.lith_classes = lith_classes
        self.lith_emb = nn.Embedding(lith_classes, lith_dim) if lith_classes > 0 else None
        cin = in_channels + (lith_dim if lith_classes > 0 else 0)

        self.stem = ConvBlock(cin, width, dropout=dropout)
        self.downs = nn.ModuleList()
        self.pools = nn.ModuleList()
        ch = width
        for i in range(depth - 1):
            nch = min(width * (2 ** (i + 1)), 512)
            self.pools.append(nn.MaxPool1d(2))
            self.downs.append(ConvBlock(ch, nch, dropout=dropout))
            ch = nch
        self.bottleneck = ConvBlock(ch, ch, dropout=dropout)

        self.ups = nn.ModuleList()
        self.up_convs = nn.ModuleList()
        for i in reversed(range(depth - 1)):
            nch = min(width * (2**i), 512)
            self.up_convs.append(nn.Conv1d(ch, nch, 1))
            self.ups.append(ConvBlock(nch * 2, nch, dropout=dropout))
            ch = nch
        self.head = nn.Conv1d(ch, 1, 1)

    def forward(self, x, lith=None):
        if self.lith_emb is not None and lith is not None:
            e = self.lith_emb(lith.long()).transpose(1, 2)  # B, emb, L
            x = torch.cat([x, e], dim=1)
        h = self.stem(x)
        skips = [h]
        for pool, down in zip(self.pools, self.downs):
            h = down(pool(h))
            skips.append(h)
        h = self.bottleneck(h)
        for i, (up_conv, up) in enumerate(zip(self.up_convs, self.ups)):
            skip = skips[len(skips) - 2 - i]
            h = F.interpolate(h, size=skip.shape[-1], mode="nearest")
            h = up_conv(h)
            h = up(torch.cat([h, skip], dim=1))
        return self.head(h)


# --------------------------------------------------------------------------
# 便捷构造
# --------------------------------------------------------------------------
def count_params(model: nn.Module) -> int:
    return sum(p.numel() for p in model.parameters() if p.requires_grad)
