r"""梯度提升树基线（HistGradientBoosting）：对缺失值天然友好，是强力的逐点对照模型。

它不是课件里的方法，但作为「集成学习」对照很有说服力：
    - 逐点、不看邻点，却能逼近序列模型，说明曲线本身信息量很大
    - 可以用来核对 U-Net 的结果是否合理

运行：
    .\.venv\Scripts\python.exe src\train_gbdt.py --name gbdt_all --curves all --lith
"""
from __future__ import annotations

import argparse
import json
import time

import joblib
import numpy as np
from sklearn.ensemble import HistGradientBoostingRegressor

import config as C
from data_prep import load_cache
from evaluation import compute_metrics, per_well_table, summarize_row
from train_point import build_X


def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument("--name", type=str, default="gbdt")
    ap.add_argument("--curves", type=str, default="all")
    ap.add_argument("--well_norm", action="store_true")
    ap.add_argument("--lith", action="store_true")
    ap.add_argument("--no_depth", action="store_true")
    ap.add_argument("--max_iter", type=int, default=400)
    ap.add_argument("--lr", type=float, default=0.06)
    ap.add_argument("--leaves", type=int, default=63)
    ap.add_argument("--min_samples_leaf", type=int, default=50)
    ap.add_argument("--l2", type=float, default=1.0)
    return ap.parse_args()


if __name__ == "__main__":
    args = parse_args()
    C.seed_everything()
    data, meta = load_cache()
    if args.curves == "core4":
        curves = list(C.CORE4)
    elif args.curves == "all":
        curves = list(C.CURVES)
    else:
        curves = [c.strip() for c in args.curves.split(",") if c.strip()]

    X, feat_names = build_X(data, curves, args.well_norm, args.lith, not args.no_depth)
    y = data["target"]
    is_test = data["is_test"].astype(bool)
    core4 = data["core4"]
    if args.curves == "core4":
        tr = np.where(~is_test & core4)[0]
        te_all = np.where(is_test & core4)[0]
    else:
        tr = np.where(~is_test)[0]
        te_all = np.where(is_test)[0]
    te_c4 = np.where(is_test & core4)[0]
    print(f"特征 {X.shape[1]} 维，训练 {len(tr):,}，测试 {len(te_all):,}")

    t0 = time.time()
    model = HistGradientBoostingRegressor(
        max_iter=args.max_iter, learning_rate=args.lr, max_leaf_nodes=args.leaves,
        min_samples_leaf=args.min_samples_leaf, l2_regularization=args.l2,
        early_stopping=True, validation_fraction=0.1, n_iter_no_change=20,
        random_state=C.SEED,
    )
    model.fit(X[tr], y[tr])
    pred = model.predict(X[te_all])
    pred_c4 = model.predict(X[te_c4])
    m_all = compute_metrics(y[te_all], pred, data["well_id"][te_all])
    m_c4 = compute_metrics(y[te_c4], pred_c4, data["well_id"][te_c4])

    full_pred = np.full(len(y), np.nan)
    full_pred[te_all] = pred
    full_pred[te_c4] = pred_c4
    np.savez_compressed(C.OUT_PRED / f"pred_{args.name}.npz", pred=full_pred, y=y,
                        well_id=data["well_id"], is_test=is_test, core4=core4, depth_m=data["depth_m"])
    tbl = per_well_table(y[te_all], pred, data["well_id"][te_all], list(data["well_names"]))
    tbl.to_csv(C.OUT_TAB / f"per_well_{args.name}.csv", index=False, encoding="utf-8-sig")
    joblib.dump(model, C.OUT_MODEL / f"{args.name}.joblib", compress=3)

    result = {
        "name": args.name, "args": vars(args), "curves": curves, "n_features": X.shape[1],
        "n_iter": int(model.n_iter_), "time_min": (time.time() - t0) / 60,
        "all": m_all, "core4": m_c4,
        "row_all": summarize_row(args.name, m_all), "row_core4": summarize_row(args.name, m_c4),
    }
    (C.OUT_TAB / f"metrics_{args.name}.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print("== 全部测试行 ==", json.dumps(result["row_all"], ensure_ascii=False))
    print("== core4 测试行 ==", json.dumps(result["row_core4"], ensure_ascii=False))
    print(f"用时 {result['time_min']:.1f} min，迭代 {model.n_iter_} 次，模型 -> {C.OUT_MODEL / (args.name + '.joblib')}")
