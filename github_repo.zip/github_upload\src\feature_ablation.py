r"""特征消融实验：回答「多加曲线到底有没有用」。

两组实验：
    A. 严格 core4 口径（与上一版可比）：只用 GR/RHOB/NPHI/RDEP 的行，
       比较 4 曲线 / +深度 / +岩性
    B. 全数据口径：缺失曲线用掩码处理，不删行，
       逐步加入 井径类 / PEF+SP / 电阻率族 / 横波+钻速 / 伽马能谱

输出：
    outputs/tables/ablation_core4.csv
    outputs/tables/ablation_multicurve.csv
    outputs/figures/ablation.png
"""
from __future__ import annotations

import json
import time

import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor

import config as C
from data_prep import load_cache
from evaluation import compute_metrics


def fit_eval(name, curves, add_depth, add_lith, pool_core4, data, meta):
    idx = [C.CURVES.index(c) for c in curves]
    parts = [data["x_global"][:, idx], data["mask"][:, idx]]
    if add_depth:
        parts.append(data["depth_z"].reshape(-1, 1))
    if add_lith:
        parts.append(data["lith"].reshape(-1, 1).astype(np.float32))
    X = np.hstack(parts)
    y = data["target"]
    is_test = data["is_test"].astype(bool)
    core4 = data["core4"]
    if pool_core4:
        tr = np.where(~is_test & core4)[0]
        te = np.where(is_test & core4)[0]
    else:
        tr = np.where(~is_test)[0]
        te = np.where(is_test)[0]

    model = HistGradientBoostingRegressor(
        max_iter=300, learning_rate=0.06, max_leaf_nodes=63,
        min_samples_leaf=50, l2_regularization=1.0,
        early_stopping=False,
        random_state=C.SEED,
    )
    t0 = time.time()
    model.fit(X[tr], y[tr])
    met = compute_metrics(y[te], model.predict(X[te]), data["well_id"][te])
    print(f"  {name:32s} 曲线{len(curves):2d} 特征{X.shape[1]:3d} "
          f"R2={met['R2']:.4f} 井内={met['R2_within_median']:.4f} MAE={met['MAE']:.2f} ({time.time()-t0:.0f}s)")
    return {
        "特征组": name, "曲线数": len(curves), "特征数": X.shape[1],
        "整体R2": round(met["R2"], 4), "单井R2中位数": round(met["R2_within_median"], 4),
        "MAE": round(met["MAE"], 3), "RMSE": round(met["RMSE"], 3),
        "测评点数": met["n"], "测评井数": met["n_wells"],
    }


def main():
    data, meta = load_cache()
    G = C.FEATURE_GROUPS
    all_curves = list(C.CURVES)
    core4 = list(C.CORE4)

    print("A. 严格 core4 口径（与上一版可比）")
    rows_a = [
        fit_eval("4曲线（上一版输入）", core4, False, False, True, data, meta),
        fit_eval("4曲线+深度", core4, True, False, True, data, meta),
        fit_eval("4曲线+深度+岩性", core4, True, True, True, data, meta),
    ]
    df_a = pd.DataFrame(rows_a)
    df_a.to_csv(C.OUT_TAB / "ablation_core4.csv", index=False, encoding="utf-8-sig")

    print("B. 全数据口径（多曲线+掩码，不删行）")
    rows_b = []
    cur = list(G["G1_基础四曲线"])
    rows_b.append(fit_eval("4条基础曲线", cur, True, False, False, data, meta))
    for gname in ["G2_井径与密度校正", "G3_三孔隙度与光电", "G4_电阻率族", "G5_横波与钻速", "G6_自然伽马能谱"]:
        cur = cur + list(G[gname])
        rows_b.append(fit_eval(f"+{gname}", cur, True, False, False, data, meta))
    rows_b.append(fit_eval("18条曲线+深度+岩性", all_curves, True, True, False, data, meta))
    rows_b.append(fit_eval("18条曲线+深度（无岩性）", all_curves, True, False, False, data, meta))
    df_b = pd.DataFrame(rows_b)
    df_b.to_csv(C.OUT_TAB / "ablation_multicurve.csv", index=False, encoding="utf-8-sig")

    # 画图
    C.setup_matplotlib()
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(1, 2, figsize=(12, 4.2), dpi=200)
    short = {
        "4条基础曲线": "4条基础",
        "+G2_井径与密度校正": "+井径/密度",
        "+G3_三孔隙度与光电": "+PEF/SP",
        "+G4_电阻率族": "+电阻率族",
        "+G5_横波与钻速": "+DTS/钻速",
        "+G6_自然伽马能谱": "+能谱",
        "18条曲线+深度+岩性": "18条+岩性",
        "18条曲线+深度（无岩性）": "18条",
    }
    for ax, df, title in [(axes[0], df_a, "A. 严格 4 曲线口径（与上一版可比）"),
                          (axes[1], df_b, "B. 全数据口径：逐步加入曲线组")]:
        labels = [short.get(s, s.replace("G", "").replace("_", "\n")) for s in df["特征组"]]
        x = np.arange(len(df))
        ax.bar(x - 0.2, df["整体R2"], width=0.38, label="整体 R2", color="#4c72b0")
        ax.bar(x + 0.2, df["单井R2中位数"], width=0.38, label="单井内 R2 中位数", color="#dd8452")
        ax.set_xticks(x)
        ax.set_xticklabels(labels, fontsize=7.5)
        ax.set_ylim(0.75, 0.93)
        ax.axhline(0.635, color="gray", ls="--", lw=1)
        ax.axhline(0.836, color="gray", ls=":", lw=1)
        ax.set_title(title, fontsize=10)
        ax.grid(axis="y", alpha=0.3)
        ax.legend(fontsize=8, loc="lower right")
    fig.tight_layout()
    fig.savefig(C.OUT_FIG / "ablation.png", bbox_inches="tight")
    plt.close(fig)
    print(f"\n已保存 {C.OUT_TAB/'ablation_core4.csv'}、{C.OUT_TAB/'ablation_multicurve.csv'}、{C.OUT_FIG/'ablation.png'}")


if __name__ == "__main__":
    main()
