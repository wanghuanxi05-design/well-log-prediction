r"""对已保存的 U-Net 检查点重新推理并评测（不重新训练）。

用途：修正推理代码后，快速重算指标；或对同一模型换滑窗步长做稳健性检查。
运行：
    .\.venv\Scripts\python.exe src\eval_ckpt.py --ckpt outputs/models/unet_lith.pt --name unet_lith
"""
from __future__ import annotations

import argparse
import json

import numpy as np
import torch

import config as C
from data_prep import load_cache
from evaluation import compute_metrics, per_well_table, summarize_row
from models import UNet1D, count_params
from seq_data import SeqData, predict_well


def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", type=str, required=True)
    ap.add_argument("--name", type=str, default=None)
    ap.add_argument("--stride", type=int, default=None)
    return ap.parse_args()


def main():
    args = parse_args()
    C.seed_everything()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    data, meta = load_cache()
    ckpt = torch.load(args.ckpt, map_location=device, weights_only=False)
    targs = ckpt["args"]
    name = args.name or targs["name"]
    stride = args.stride or targs["stride"]
    curves = ckpt["curves"]
    seq = SeqData(data, curves, use_well_norm=not targs.get("no_well_norm", False),
                  use_lith=targs.get("lith", False))
    model = UNet1D(seq.n_channels, width=targs["width"], depth=targs["depth"],
                   lith_classes=C.N_LITH if targs.get("lith") else 0,
                   dropout=targs.get("dropout", 0.0)).to(device)
    model.load_state_dict(ckpt["state_dict"])
    model.eval()

    pred = np.full(len(data["target"]), np.nan, dtype=np.float64)
    for w in seq.test:
        pz = predict_well(model, w, targs["length"], stride, device)
        s, e = int(data["offsets"][w["wid"]]), int(data["offsets"][w["wid"] + 1])
        pred[s:e] = pz * meta["target_scale"] + meta["target_median"]

    is_test = data["is_test"].astype(bool)
    core4 = data["core4"]
    v_all = is_test & np.isfinite(pred)
    v_c4 = v_all & core4
    m_all = compute_metrics(data["target"][v_all], pred[v_all], data["well_id"][v_all])
    m_c4 = compute_metrics(data["target"][v_c4], pred[v_c4], data["well_id"][v_c4])
    tbl = per_well_table(data["target"][v_all], pred[v_all], data["well_id"][v_all], list(data["well_names"]))
    tbl.to_csv(C.OUT_TAB / f"per_well_{name}.csv", index=False, encoding="utf-8-sig")
    np.savez_compressed(C.OUT_PRED / f"pred_{name}.npz", pred=pred, y=data["target"],
                        well_id=data["well_id"], is_test=is_test, core4=core4, depth_m=data["depth_m"])
    res = {"name": name, "args": targs, "curves": curves, "params_m": count_params(model) / 1e6,
           "all": m_all, "core4": m_c4,
           "row_all": summarize_row(name, m_all), "row_core4": summarize_row(name, m_c4)}
    (C.OUT_TAB / f"metrics_{name}.json").write_text(json.dumps(res, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(res["row_all"], ensure_ascii=False))
    print(json.dumps(res["row_core4"], ensure_ascii=False))


if __name__ == "__main__":
    main()
