"""全局配置：路径、数据列、清洗阈值、划分与绘图风格。

所有脚本共用本文件，保证口径一致（尤其评测口径要与上一版可比）。
"""
from __future__ import annotations

import os
import random
from pathlib import Path

import numpy as np

# ---------------- 路径 ----------------
ROOT = Path(__file__).resolve().parents[1]
DATA_RAW = ROOT / "data" / "raw" / "train.csv"
DATA_LAS = ROOT / "data" / "las"
DATA_PROC = ROOT / "data" / "processed"
OUT = ROOT / "outputs"
OUT_FIG = OUT / "figures"
OUT_TAB = OUT / "tables"
OUT_MODEL = OUT / "models"
OUT_PRED = OUT / "predictions"
for _p in (DATA_PROC, OUT_FIG, OUT_TAB, OUT_MODEL, OUT_PRED):
    _p.mkdir(parents=True, exist_ok=True)

CACHE_VERSION = "v3"  # 数据缓存格式版本，改动预处理逻辑时 +1

# ---------------- 随机性 ----------------
SEED = 42
N_TEST_WELLS = 29

# ---------------- 曲线与清洗阈值 ----------------
# 单位：GR API, RHOB g/cm3, NPHI v/v, 电阻率 ohm·m, CALI/BS in, SP mV, PEF barn/e,
#       DTC/DTS μs/ft, ROP ft/h, DCAL in, DRHO g/cm3
CURVES = [
    "GR", "SGR", "RHOB", "DRHO", "NPHI", "PEF",
    "RDEP", "RMED", "RSHA", "RXO", "RMIC",
    "CALI", "BS", "DCAL", "SP", "DTS", "ROP", "ROPA",
]
# 这些曲线动态范围大、近似对数分布，先取 log10
LOG_CURVES = {"RDEP", "RMED", "RSHA", "RXO", "RMIC", "ROP", "ROPA"}
TARGET = "DTC"

PHYS_RANGE = {
    "GR": (0.0, 300.0),
    "SGR": (0.0, 300.0),
    "RHOB": (1.0, 3.2),
    "DRHO": (-0.5, 0.5),
    "NPHI": (-0.15, 1.0),
    "PEF": (0.0, 20.0),
    "RDEP": (0.05, 2000.0),
    "RMED": (0.05, 2000.0),
    "RSHA": (0.05, 2000.0),
    "RXO": (0.05, 2000.0),
    "RMIC": (0.05, 2000.0),
    "CALI": (5.0, 40.0),
    "BS": (5.0, 40.0),
    "DCAL": (-10.0, 10.0),
    "SP": (-300.0, 300.0),
    "DTS": (40.0, 700.0),
    "ROP": (0.01, 1000.0),
    "ROPA": (0.01, 300.0),
    "DTC": (40.0, 200.0),
}

# 必需曲线：目标 + GR 始终存在；其余靠掩码
REQUIRED_ALWAYS = ["GR", "DTC"]
CORE4 = ["GR", "RHOB", "NPHI", "RDEP"]  # 与上一版一致的 4 条输入

# 特征分组：用于消融实验与正式模型
FEATURE_GROUPS = {
    "G1_基础四曲线": ["GR", "RHOB", "NPHI", "RDEP"],
    "G2_井径与密度校正": ["CALI", "BS", "DRHO", "DCAL"],
    "G3_三孔隙度与光电": ["PEF", "SP"],
    "G4_电阻率族": ["RMED", "RSHA", "RXO", "RMIC"],
    "G5_横波与钻速": ["DTS", "ROP", "ROPA"],
    "G6_自然伽马能谱": ["SGR"],
}

# ---------------- 岩性 ----------------
LITH_NAME = {
    30000: "砂岩",
    65030: "砂页岩互层",
    65000: "页岩",
    80000: "泥灰岩",
    74000: "白云岩",
    70000: "石灰岩",
    70032: "白垩",
    88000: "盐岩",
    86000: "硬石膏",
    99000: "基底",
    90000: "煤",
    93000: "凝灰岩",
}
LITH_CODES = sorted(LITH_NAME)  # 12 类固定顺序
LITH_TO_ID = {code: i for i, code in enumerate(LITH_CODES)}
N_LITH = len(LITH_CODES) + 1  # 最后一位留给未知
UNKNOWN_LITH_ID = N_LITH - 1


def lith_to_id(codes) -> np.ndarray:
    """把岩性编码映射为 0..11，未知映射到 12。"""
    return np.array([LITH_TO_ID.get(int(c), UNKNOWN_LITH_ID) for c in codes], dtype=np.int8)


# ---------------- 评测 ----------------
METRIC_NAMES = ["MAE", "RMSE", "R2", "R2_within_median", "R2_within_mean"]


def seed_everything(seed: int = SEED) -> None:
    random.seed(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)
    np.random.seed(seed)
    try:
        import torch

        torch.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
    except Exception:
        pass


def setup_matplotlib() -> None:
    """统一中文绘图风格（注意：图中不写 R²，改写 R2，避免字体缺字）。"""
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "DejaVu Sans"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["figure.dpi"] = 120
    plt.rcParams["savefig.dpi"] = 200
    plt.rcParams["axes.spines.top"] = False
    plt.rcParams["axes.spines.right"] = False
    plt.rcParams["font.size"] = 10
