r"""生成报告/PPT 用的全部图表。

运行：.\.venv\Scripts\python.exe src\plots.py
输出：outputs/figures/*.png
"""
from __future__ import annotations

import json
import re
from pathlib import Path

import numpy as np
import pandas as pd

import config as C

C.setup_matplotlib()
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

CORE4_MODELS = [
    ("线性回归\n(4曲线)", "lr_core4_nodepth"),
    ("MLP\n(4曲线)", "mlp_core4"),
    ("GBDT\n(4曲线+深度)", "gbdt_core4"),
    ("U-Net\n(18曲线)", "unet_w48"),
]
ALL_MODELS = [
    ("MLP\n(18曲线)", "mlp_all"),
    ("GBDT\n(18曲线+深度)", "gbdt_l31"),
    ("GBDT\n(+岩性)", "gbdt_all"),
    ("U-Net\n(18曲线)", "unet_w48"),
]


def load_metrics(name: str) -> dict | None:
    p = C.OUT_TAB / f"metrics_{name}.json"
    if not p.exists():
        return None
    return json.loads(p.read_text(encoding="utf-8"))


def get_metric(name: str, subset: str, key: str) -> float:
    m = load_metrics(name)
    if m is None:
        return float("nan")
    return m[subset][key]


def plot_model_compare():
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.6), dpi=200)
    for ax, models, subset, title in [
        (axes[0], CORE4_MODELS, "core4", "A. 严格 4 曲线口径（测试集 26.6 万点）"),
        (axes[1], ALL_MODELS, "all", "B. 全数据口径（测试集 33.1 万点）"),
    ]:
        labels, r2, wr2 = [], [], []
        for label, name in models:
            m = load_metrics(name)
            if m is None:
                continue
            labels.append(label)
            r2.append(m[subset]["R2"])
            wr2.append(m[subset]["R2_within_median"])
        x = np.arange(len(labels))
        ax.bar(x - 0.2, r2, 0.38, label="整体 R2", color="#4c72b0")
        ax.bar(x + 0.2, wr2, 0.38, label="单井内 R2 中位数", color="#dd8452")
        for xi, v in zip(x - 0.2, r2):
            ax.text(xi, v + 0.005, f"{v:.3f}", ha="center", fontsize=7)
        for xi, v in zip(x + 0.2, wr2):
            ax.text(xi, v + 0.005, f"{v:.3f}", ha="center", fontsize=7)
        ax.axhline(0.635, color="gray", ls="--", lw=1)
        ax.text(-0.45, 0.642, "旧版单井 R2 0.635", fontsize=7, color="#555555",
                ha="left", va="bottom", bbox=dict(facecolor="white", edgecolor="none", alpha=0.8, pad=1))
        ax.set_xticks(x)
        ax.set_xticklabels(labels, fontsize=8)
        ax.set_ylim(0.5, 1.0)
        ax.set_ylabel("R2")
        ax.set_title(title, fontsize=10)
        ax.grid(axis="y", alpha=0.3)
        ax.legend(fontsize=8, loc="lower right")
    fig.tight_layout()
    fig.savefig(C.OUT_FIG / "fig_model_compare.png", bbox_inches="tight")
    plt.close(fig)
    print("  fig_model_compare.png")


def plot_perwell(name="gbdt_l31_lith"):
    p = C.OUT_TAB / f"per_well_{name}.csv"
    if not p.exists():
        name = "gbdt_l31_lith"
        p = C.OUT_TAB / f"per_well_{name}.csv"
    df = pd.read_csv(p).sort_values("R2")
    med = df["R2"].median()
    fig, ax = plt.subplots(figsize=(11, 4.2), dpi=200)
    colors = ["#c44e52" if v < med else "#4c72b0" for v in df["R2"]]
    ax.bar(range(len(df)), df["R2"], color=colors)
    ax.axhline(med, color="k", ls="--", lw=1, label=f"中位数 {med:.3f}")
    ax.axhline(0, color="gray", lw=0.8)
    ax.set_xticks(range(len(df)))
    ax.set_xticklabels(df["well"], rotation=90, fontsize=6)
    ax.set_ylabel("单井内 R2")
    ax.set_title("逐井预测效果（GBDT 主模型，29 口测试井）")
    ax.legend(fontsize=8)
    ax.grid(axis="y", alpha=0.3)
    fig.tight_layout()
    fig.savefig(C.OUT_FIG / "fig_perwell_r2.png", bbox_inches="tight")
    plt.close(fig)
    print("  fig_perwell_r2.png")


def plot_scatter(name="gbdt_l31_lith"):
    p = C.OUT_PRED / f"pred_{name}.npz"
    if not p.exists():
        name = "gbdt_l31_lith"
        p = C.OUT_PRED / f"pred_{name}.npz"
    d = np.load(p)
    y, pred = d["y"], d["pred"]
    m = d["is_test"].astype(bool) & np.isfinite(pred)
    y, pred = y[m], pred[m]
    from evaluation import compute_metrics
    met = compute_metrics(y, pred, d["well_id"][m])
    fig, ax = plt.subplots(figsize=(5.2, 4.6), dpi=200)
    hb = ax.hexbin(y, pred, gridsize=80, cmap="viridis", bins="log", mincnt=1)
    lim = [50, 210]
    ax.plot(lim, lim, "r--", lw=1)
    ax.set_xlim(lim)
    ax.set_ylim(lim)
    ax.set_xlabel("真实 DTC (μs/ft)")
    ax.set_ylabel("预测 DTC (μs/ft)")
    ax.set_title(f"预测 vs 真实（GBDT 主模型）\nMAE={met['MAE']:.2f}  R2={met['R2']:.3f}", fontsize=10)
    fig.colorbar(hb, ax=ax, label="点数（对数）")
    fig.tight_layout()
    fig.savefig(C.OUT_FIG / "fig_scatter.png", bbox_inches="tight")
    plt.close(fig)
    print("  fig_scatter.png")


def plot_residual(name="gbdt_l31_lith"):
    p = C.OUT_PRED / f"pred_{name}.npz"
    d = np.load(p)
    y, pred = d["y"], d["pred"]
    m = d["is_test"].astype(bool) & np.isfinite(pred)
    res = pred[m] - y[m]
    fig, ax = plt.subplots(figsize=(6, 3.8), dpi=200)
    ax.hist(res, bins=120, range=(-40, 40), color="#4c72b0", alpha=0.85)
    ax.axvline(0, color="k", lw=0.8)
    ax.set_xlabel("残差 = 预测 - 真实 (μs/ft)")
    ax.set_ylabel("点数")
    ax.set_title(f"残差分布（均值 {res.mean():+.2f}，RMSE {np.sqrt((res**2).mean()):.2f}）")
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(C.OUT_FIG / "fig_residual.png", bbox_inches="tight")
    plt.close(fig)
    print("  fig_residual.png")


def plot_dtc_depth():
    df = pd.read_csv(C.DATA_RAW, sep=";", usecols=["WELL", "DEPTH_MD", "DTC"])
    df = df.dropna(subset=["DTC", "DEPTH_MD"])
    df["quad"] = df["WELL"].str.split("/").str[0]
    quads = sorted(df["quad"].unique())
    cmap = plt.get_cmap("tab20")
    fig, ax = plt.subplots(figsize=(6.4, 6.8), dpi=200)
    for i, q in enumerate(quads):
        sub = df[df["quad"] == q]
        ax.scatter(sub["DTC"], sub["DEPTH_MD"], s=1, alpha=0.25, color=cmap(i % 20), label=q)
    ax.invert_yaxis()
    ax.set_xlabel("DTC (μs/ft)")
    ax.set_ylabel("深度 (m)")
    ax.set_title("DTC 随深度的压实趋势（按象限着色）")
    ax.legend(fontsize=6, ncol=2, markerscale=6, loc="lower right")
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(C.OUT_FIG / "fig_dtc_depth.png", bbox_inches="tight")
    plt.close(fig)
    print("  fig_dtc_depth.png")


def plot_map():
    df = pd.read_csv(C.DATA_RAW, sep=";", usecols=["WELL", "X_LOC", "Y_LOC"])
    pos = df.groupby("WELL")[["X_LOC", "Y_LOC"]].first().reset_index()
    meta = json.loads((C.DATA_PROC / "meta.json").read_text(encoding="utf-8"))
    test = set(meta["test_wells"])
    pos["split"] = pos["WELL"].map(lambda w: "测试井" if w in test else "训练井")
    fig, ax = plt.subplots(figsize=(6.6, 5.2), dpi=200)
    for label, color, size in [("训练井", "#8c8c8c", 18), ("测试井", "#d1495b", 28)]:
        sub = pos[pos["split"] == label]
        ax.scatter(sub["X_LOC"] / 1000, sub["Y_LOC"] / 1000, s=size, color=color, label=f"{label} ({len(sub)})")
    ax.set_xlabel("X (km)")
    ax.set_ylabel("Y (km)")
    ax.set_title("98 口井平面分布与训练/测试划分")
    ax.legend(fontsize=8)
    ax.grid(alpha=0.3)
    ax.set_aspect("equal", adjustable="box")
    ax.set_xlim(400, 600)
    ax.set_ylim(6380, 6860)
    fig.tight_layout()
    fig.savefig(C.OUT_FIG / "fig_map.png", bbox_inches="tight")
    plt.close(fig)
    print("  fig_map.png")


def plot_corr():
    cols = ["GR", "SGR", "RHOB", "DRHO", "NPHI", "PEF", "RDEP", "RMED", "RSHA",
            "RXO", "RMIC", "CALI", "BS", "DCAL", "SP", "DTS", "ROP", "ROPA", "DTC"]
    df = pd.read_csv(C.DATA_RAW, sep=";", usecols=cols).sample(200_000, random_state=C.SEED)
    corr = df.corr()
    fig, ax = plt.subplots(figsize=(7.6, 6.4), dpi=200)
    im = ax.imshow(corr.values, cmap="RdBu_r", vmin=-1, vmax=1)
    ax.set_xticks(range(len(cols)))
    ax.set_xticklabels(cols, rotation=90, fontsize=7)
    ax.set_yticks(range(len(cols)))
    ax.set_yticklabels(cols, fontsize=7)
    for i in range(len(cols)):
        for j in range(len(cols)):
            if abs(corr.values[i, j]) >= 0.5 and i != j:
                ax.text(j, i, f"{corr.values[i,j]:.2f}", ha="center", va="center", fontsize=5)
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    ax.set_title("曲线相关系数矩阵（19 万采样点）")
    fig.tight_layout()
    fig.savefig(C.OUT_FIG / "fig_corr.png", bbox_inches="tight")
    plt.close(fig)
    print("  fig_corr.png")


def plot_loss(name="unet_w48"):
    p = C.OUT_TAB / f"log_{name}.txt"
    if not p.exists():
        return
    train, val, epochs = [], [], []
    for line in p.read_text(encoding="utf-8").splitlines():
        m = re.match(r"epoch (\d+) \| train ([\d.]+) \| val ([\d.]+)", line)
        if m:
            epochs.append(int(m.group(1)))
            train.append(float(m.group(2)))
            val.append(float(m.group(3)))
    fig, ax = plt.subplots(figsize=(5.6, 3.8), dpi=200)
    ax.plot(epochs, train, marker="o", ms=3, label="训练损失")
    ax.plot(epochs, val, marker="s", ms=3, label="验证损失")
    ax.set_xlabel("epoch")
    ax.set_ylabel("SmoothL1 损失（标准化 DTC）")
    ax.set_title("U-Net 训练曲线")
    ax.legend(fontsize=8)
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(C.OUT_FIG / "fig_loss.png", bbox_inches="tight")
    plt.close(fig)
    print("  fig_loss.png")


def plot_ablation():
    p = C.OUT_TAB / "ablation_multicurve.csv"
    if not p.exists():
        return
    df = pd.read_csv(p)
    short = {
        "4条基础曲线": "4条基础",
        "+G2_井径与密度校正": "+井径/密度",
        "+G3_三孔隙度与光电": "+PEF/SP",
        "+G4_电阻率族": "+电阻率族",
        "+G5_横波与钻速": "+DTS/钻速",
        "+G6_自然伽马能谱": "+能谱",
        "18条曲线+深度+岩性": "18条+岩性",
        "18条曲线+深度（无岩性）": "18条",
    }
    fig, ax = plt.subplots(figsize=(7.4, 3.8), dpi=200)
    x = np.arange(len(df))
    ax.plot(x, df["整体R2"], marker="o", label="整体 R2", color="#4c72b0")
    ax.plot(x, df["单井R2中位数"], marker="s", label="单井内 R2 中位数", color="#dd8452")
    ax.set_xticks(x)
    ax.set_xticklabels([short.get(s, s.replace("G", "").replace("_", "\n")) for s in df["特征组"]], fontsize=8)
    ax.set_ylim(0.80, 0.925)
    ax.grid(axis="y", alpha=0.3)
    ax.legend(fontsize=8)
    ax.set_title("多曲线消融：逐步加入曲线组的增益")
    fig.tight_layout()
    fig.savefig(C.OUT_FIG / "fig_ablation.png", bbox_inches="tight")
    plt.close(fig)
    print("  fig_ablation.png")


def plot_well_spread():
    """98 口井 DTC 中位数与四分位范围，说明井间基准差异。"""
    df = pd.read_csv(C.DATA_RAW, sep=";", usecols=["WELL", "DTC"]).dropna(subset=["DTC"])
    g = df.groupby("WELL")["DTC"].agg(median="median", q1=lambda s: s.quantile(0.25),
                                      q3=lambda s: s.quantile(0.75)).sort_values("median")
    quad = [w.split("/")[0] for w in g.index]
    quads = sorted(set(quad))
    cmap = plt.get_cmap("tab20")
    colors = [cmap(quads.index(q) % 20) for q in quad]
    fig, ax = plt.subplots(figsize=(7.0, 4.2), dpi=200)
    x = np.arange(len(g))
    ax.errorbar(x, g["median"], yerr=[g["median"] - g["q1"], g["q3"] - g["median"]],
                fmt="o", ms=3.2, lw=0.8, capsize=0, color="#4c72b0", ecolor="#b9c6d2", alpha=0.9)
    ax.axhline(g["median"].median(), color="#c44e52", ls="--", lw=1, label=f"98 口井中位数 {g['median'].median():.1f}")
    ax.set_xlim(-2, len(g) + 1)
    ax.set_xticks([])
    ax.set_xlabel("98 口井（按中位数排序）")
    ax.set_ylabel("DTC (μs/ft)")
    ax.set_title("每口井的 DTC 中位数与四分位范围", fontsize=10)
    ax.legend(fontsize=8, loc="upper left")
    ax.grid(axis="y", alpha=0.3)
    fig.tight_layout()
    fig.savefig(C.OUT_FIG / "fig_well_spread.png", bbox_inches="tight")
    plt.close(fig)
    print("  fig_well_spread.png")


def plot_depth_norm():
    """说明为什么用深度趋势和井内标准化：单井压实趋势 + 井间基准差异。"""
    cols = ["WELL", "DEPTH_MD", "DTC", "GR"]
    df = pd.read_csv(C.DATA_RAW, sep=";", usecols=cols).dropna(subset=["DTC", "DEPTH_MD"])
    w = df[df["WELL"] == "15/9-13"].sort_values("DEPTH_MD")
    med = df.groupby("WELL")["DTC"].median()

    fig, axes = plt.subplots(1, 2, figsize=(10.5, 4.2), dpi=200,
                             gridspec_kw={"width_ratios": [1.15, 1]})
    ax = axes[0]
    sc = ax.scatter(w["DTC"], w["DEPTH_MD"], c=w["GR"], s=2, cmap="viridis", alpha=0.6)
    roll = w["DTC"].rolling(301, center=True, min_periods=50).median()
    ax.plot(roll, w["DEPTH_MD"], color="#c44e52", lw=1.6, label="滑动中位数")
    ax.invert_yaxis()
    ax.set_xlabel("DTC (μs/ft)")
    ax.set_ylabel("深度 (m)")
    ax.set_title("同一口井：DTC 随深度呈压实趋势", fontsize=10)
    ax.legend(fontsize=8, loc="lower right")
    ax.grid(alpha=0.3)
    cb = fig.colorbar(sc, ax=ax, fraction=0.04, pad=0.02)
    cb.set_label("GR (API)", fontsize=8)

    ax = axes[1]
    ax.hist(med, bins=18, color="#4c72b0", edgecolor="white")
    ax.axvline(med.median(), color="#c44e52", ls="--", lw=1.2, label=f"中位数 {med.median():.1f}")
    ax.set_xlabel("各井 DTC 中位数 (μs/ft)")
    ax.set_ylabel("井数")
    ax.set_title("98 口井：井间基准差异明显", fontsize=10)
    ax.legend(fontsize=8)
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(C.OUT_FIG / "fig_depth_norm.png", bbox_inches="tight")
    plt.close(fig)
    print("  fig_depth_norm.png")


if __name__ == "__main__":
    print("生成图表...")
    plot_model_compare()
    plot_perwell()
    plot_scatter()
    plot_residual()
    plot_dtc_depth()
    plot_well_spread()
    plot_depth_norm()
    plot_map()
    plot_corr()
    plot_loss()
    plot_ablation()
    print("完成。")
