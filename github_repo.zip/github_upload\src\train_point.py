r"""点预测基线：最小二乘线性回归、MLP（逐点）。

与 U-Net 的区别：这里每个采样点独立预测，不看上下邻点。
用于回答两个问题：
    1. 只用 4 条曲线能做到多少（复现上一版基线）
    2. 多曲线 / 深度 / 岩性 / 井内标准化各带来多少增益

运行示例：
    .\.venv\Scripts\python.exe src\train_point.py --model lr --name lr_core4 --curves core4
    .\.venv\Scripts\python.exe src\train_point.py --model mlp --name mlp_all --curves all --lith --well_norm
"""
from __future__ import annotations

import argparse
import json
import time

import numpy as np
import torch
import torch.nn as nn

import config as C
from data_prep import load_cache
from evaluation import compute_metrics, per_well_table, summarize_row
from models import MLP, count_params


def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", choices=["lr", "mlp"], default="mlp")
    ap.add_argument("--name", type=str, default="mlp")
    ap.add_argument("--curves", type=str, default="core4", help="core4 / all / 逗号分隔")
    ap.add_argument("--well_norm", action="store_true")
    ap.add_argument("--lith", action="store_true")
    ap.add_argument("--no_depth", action="store_true")
    ap.add_argument("--hidden", type=str, default="256,256,128")
    ap.add_argument("--dropout", type=float, default=0.1)
    ap.add_argument("--bs", type=int, default=4096)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--weight_decay", type=float, default=1e-4)
    ap.add_argument("--epochs", type=int, default=30)
    ap.add_argument("--patience", type=int, default=6)
    return ap.parse_args()


def build_X(data, curves, well_norm: bool, lith: bool, depth: bool):
    idx = [C.CURVES.index(c) for c in curves]
    parts = [data["x_global"][:, idx], data["mask"][:, idx]]
    names = [f"{c}_z" for c in curves] + [f"{c}_mask" for c in curves]
    if well_norm:
        parts.append(data["x_well"][:, idx])
        names += [f"{c}_wz" for c in curves]
    if depth:
        parts.append(data["depth_z"].reshape(-1, 1))
        names.append("depth_z")
    if lith:
        onehot = np.eye(C.N_LITH, dtype=np.float32)[data["lith"]]
        parts.append(onehot)
        names += [f"lith_{i}" for i in range(C.N_LITH)]
    X = np.hstack(parts).astype(np.float32)
    return X, names


def train_mlp(X, y, tr_idx, va_idx, te_idx, args, device):
    model = MLP(X.shape[1], tuple(int(h) for h in args.hidden.split(",")), args.dropout).to(device)
    print(f"MLP 输入 {X.shape[1]} 维，参数量 {count_params(model)/1e6:.2f} M")
    Xt = torch.from_numpy(X[tr_idx]).to(device)
    yt = torch.from_numpy(y[tr_idx]).to(device)
    Xv = torch.from_numpy(X[va_idx]).to(device)
    yv = torch.from_numpy(y[va_idx]).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    epochs = args.epochs
    sched = torch.optim.lr_scheduler.OneCycleLR(
        opt, max_lr=args.lr, total_steps=epochs * max(1, len(tr_idx) // args.bs), pct_start=0.2
    )
    scaler = torch.amp.GradScaler("cuda", enabled=device.type == "cuda")
    loss_fn = nn.SmoothL1Loss(beta=1.0)
    rng = np.random.default_rng(C.SEED)
    best, best_state, bad = float("inf"), None, 0
    n = len(tr_idx)
    for ep in range(1, epochs + 1):
        model.train()
        perm = rng.permutation(n)
        tot = 0.0
        for i in range(0, n, args.bs):
            sel = torch.from_numpy(perm[i:i + args.bs]).to(device)
            xb, yb = Xt[sel], yt[sel]
            with torch.autocast("cuda", dtype=torch.float16, enabled=device.type == "cuda"):
                out = model(xb)
                loss = loss_fn(out, yb)
            opt.zero_grad(set_to_none=True)
            scaler.scale(loss).backward()
            scaler.step(opt)
            scaler.update()
            sched.step()
            tot += float(loss.detach()) * len(sel)
        model.eval()
        with torch.no_grad(), torch.autocast("cuda", dtype=torch.float16, enabled=device.type == "cuda"):
            vloss = float(loss_fn(model(Xv), yv))
        print(f"  epoch {ep:02d} train {tot/n:.4f} val {vloss:.4f}")
        if vloss < best - 1e-5:
            best, bad = vloss, 0
            best_state = {k: v.detach().clone() for k, v in model.state_dict().items()}
        else:
            bad += 1
            if bad >= args.patience:
                print("  早停")
                break
    model.load_state_dict(best_state)
    return model, best


def predict_in_batches(model, X, idx, device, bs=8192):
    model.eval()
    out = np.empty(len(idx), dtype=np.float64)
    with torch.no_grad(), torch.autocast("cuda", dtype=torch.float16, enabled=device.type == "cuda"):
        for i in range(0, len(idx), bs):
            xb = torch.from_numpy(X[idx[i:i + bs]]).to(device)
            out[i:i + bs] = model(xb).float().cpu().numpy()
    return out


if __name__ == "__main__":
    args = parse_args()
    C.seed_everything()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    data, meta = load_cache()
    if args.curves == "core4":
        curves = list(C.CORE4)
    elif args.curves == "all":
        curves = list(C.CURVES)
    else:
        curves = [c.strip() for c in args.curves.split(",") if c.strip()]

    X, feat_names = build_X(data, curves, args.well_norm, args.lith, not args.no_depth)
    y = data["target"].astype(np.float32)
    is_test = data["is_test"].astype(bool)
    core4 = data["core4"]
    # 与上一版可比：core4 实验只在 core4 行上训练；多曲线实验用全部行
    if args.curves == "core4":
        pool = np.where(core4 & ~is_test)[0]
        test_idx = np.where(core4 & is_test)[0]
        test_c4_idx = test_idx
    else:
        pool = np.where(~is_test)[0]
        test_idx = np.where(is_test)[0]
        test_c4_idx = np.where(core4 & is_test)[0]

    # 在训练井内再划 10% 井做验证（不能按行随机，否则泄漏）
    train_wells = np.unique(data["well_id"][pool])
    rng = np.random.RandomState(C.SEED)
    va_wells = set(rng.choice(train_wells, size=max(4, len(train_wells) // 10), replace=False).tolist())
    is_va = np.isin(data["well_id"], list(va_wells))
    tr_idx = pool[~is_va[pool]]
    va_idx = pool[is_va[pool]]
    print(f"曲线 {len(curves)} 条，特征 {len(feat_names)} 维；训练 {len(tr_idx):,} / 验证 {len(va_idx):,} / 测试 {len(test_idx):,}")

    t0 = time.time()
    y_fit = y if args.model == "lr" else data["target_z"].astype(np.float32)
    if args.model == "lr":
        from sklearn.linear_model import LinearRegression

        lr = LinearRegression()
        lr.fit(X[tr_idx], y_fit[tr_idx])
        pred = lr.predict(X[test_idx])
        pred_c4 = lr.predict(X[test_c4_idx])
        model_info = {"coef": lr.coef_.tolist(), "intercept": float(lr.intercept_)}
    else:
        model, best_val = train_mlp(X, y_fit, tr_idx, va_idx, test_idx, args, device)
        pred = predict_in_batches(model, X, test_idx, device) * meta["target_scale"] + meta["target_median"]
        pred_c4 = predict_in_batches(model, X, test_c4_idx, device) * meta["target_scale"] + meta["target_median"]
        torch.save({"state_dict": model.state_dict(), "args": vars(args), "curves": curves,
                    "feature_names": feat_names, "target_median": meta["target_median"],
                    "target_scale": meta["target_scale"]}, C.OUT_MODEL / f"{args.name}.pt")
        model_info = {"params_m": count_params(model) / 1e6, "best_val": best_val}

    m_all = compute_metrics(y[test_idx], pred, data["well_id"][test_idx])
    m_c4 = compute_metrics(y[test_c4_idx], pred_c4, data["well_id"][test_c4_idx])

    full_pred = np.full(len(y), np.nan)
    full_pred[test_idx] = pred
    full_pred[test_c4_idx] = pred_c4
    np.savez_compressed(C.OUT_PRED / f"pred_{args.name}.npz", pred=full_pred, y=y,
                        well_id=data["well_id"], is_test=is_test, core4=core4, depth_m=data["depth_m"])
    tbl = per_well_table(y[test_idx], pred, data["well_id"][test_idx], list(data["well_names"]))
    tbl.to_csv(C.OUT_TAB / f"per_well_{args.name}.csv", index=False, encoding="utf-8-sig")
    result = {
        "name": args.name, "model": args.model, "args": vars(args), "curves": curves,
        "n_features": len(feat_names), "model_info": model_info,
        "all": m_all, "core4": m_c4,
        "row_all": summarize_row(args.name, m_all), "row_core4": summarize_row(args.name, m_c4),
        "time_min": (time.time() - t0) / 60,
    }
    (C.OUT_TAB / f"metrics_{args.name}.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print("== 全部测试行 ==", json.dumps(result["row_all"], ensure_ascii=False))
    print("== core4 测试行 ==", json.dumps(result["row_core4"], ensure_ascii=False))
    print(f"用时 {result['time_min']:.1f} min")
