r"""单井预测脚本（GBDT 单模型）：输入 LAS 或 FORCE csv，输出 DTC 预测、指标和曲线图。

示例：
    .\.venv\Scripts\python.exe src\predict.py --las "data\las\31_2-19 S.las"
    .\.venv\Scripts\python.exe src\predict.py --csv data\raw\train.csv --well "15/9-13"
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

import config as C
from data_prep import load_meta
from evaluation import compute_metrics
from inference import predict_gbdt, prepare_features, read_csv_well, read_las


def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=str, default=str(C.OUT_MODEL / "gbdt_l31_lith.joblib"))
    ap.add_argument("--info", type=str, default=str(C.OUT_TAB / "metrics_gbdt_l31_lith.json"))
    ap.add_argument("--las", type=str, default=None)
    ap.add_argument("--csv", type=str, default=None)
    ap.add_argument("--well", type=str, default=None, help="csv 模式下的井名，如 15/9-13")
    ap.add_argument("--out", type=str, default=None, help="输出前缀（不含扩展名）")
    return ap.parse_args()


def plot_well(df: pd.DataFrame, pred: np.ndarray, title: str, out_png: Path, metrics: dict | None):
    C.setup_matplotlib()
    import matplotlib.pyplot as plt

    depth = df["DEPTH_MD"].to_numpy()
    fig, axes = plt.subplots(1, 4, figsize=(12, 9), sharey=True)

    ax = axes[0]
    ax.plot(df.get("GR", np.full(len(df), np.nan)), depth, lw=0.6, color="#2f6f3e")
    ax.set_title("GR (API)")
    ax.set_xlabel("GR")

    ax = axes[1]
    ax.plot(df.get("RHOB", np.full(len(df), np.nan)), depth, lw=0.6, color="#b0413e", label="RHOB")
    ax2 = ax.twiny()
    ax2.plot(df.get("NPHI", np.full(len(df), np.nan)), depth, lw=0.6, color="#2f5f9f", label="NPHI")
    ax.set_title("RHOB / NPHI", pad=24)
    ax.set_xlabel("RHOB (g/cm3)")
    ax2.set_xlabel("NPHI (v/v)")

    ax = axes[2]
    if "DTC" in df.columns:
        ax.plot(df["DTC"], depth, lw=0.8, color="#333333", label="真实 DTC")
    ax.plot(pred, depth, lw=0.8, color="#d17b0f", label="预测 DTC")
    ax.set_title("DTC (μs/ft)" + (f"\nMAE={metrics['MAE']:.2f}  R2={metrics['R2']:.3f}" if metrics else ""))
    ax.set_xlabel("DTC")
    ax.legend(fontsize=8, loc="lower right")

    ax = axes[3]
    if "DTC" in df.columns:
        ax.plot(pred - df["DTC"].to_numpy(), depth, lw=0.6, color="#6a3d9a")
        ax.axvline(0, color="k", lw=0.8)
    ax.set_title("残差 (预测-真实)")
    ax.set_xlabel("μs/ft")

    for ax in axes:
        ax.grid(alpha=0.3)
        ax.invert_yaxis()
    fig.suptitle(title, fontsize=13)
    fig.tight_layout()
    fig.savefig(out_png, bbox_inches="tight")
    plt.close(fig)


def main():
    args = parse_args()
    model = joblib.load(args.model)
    info = json.loads(Path(args.info).read_text(encoding="utf-8"))
    curves = info["curves"]
    gargs = info["args"]
    use_lith = bool(gargs.get("lith", False))
    use_well_norm = bool(gargs.get("well_norm", False))

    if args.las:
        df, well_name = read_las(args.las)
    elif args.csv and args.well:
        df, well_name = read_csv_well(args.csv, args.well)
    else:
        raise SystemExit("请指定 --las 或 (--csv 与 --well)")

    x, depth, lith, xg, xw, mask, dz, values = prepare_features(
        df, load_meta(), curves, use_well_norm, use_lith
    )
    pred = predict_gbdt(model, curves, xg, xw, mask, dz, lith,
                        use_well_norm=use_well_norm, use_lith=use_lith)

    out_csv = Path(args.out or (C.OUT_PRED / f"pred_{well_name.replace('/', '_')}")).with_suffix(".csv")
    out_png = out_csv.with_suffix(".png")
    out_csv.parent.mkdir(parents=True, exist_ok=True)

    missing = [c for c in curves if c not in df.columns]
    coverage = float(mask.mean())
    print(f"井 {well_name}：{len(df)} 个采样点，曲线覆盖率 {coverage*100:.1f}%")
    if missing:
        print("  缺少曲线（用掩码处理）:", ", ".join(missing))

    out = pd.DataFrame({"DEPTH_MD": depth, "DTC_pred": pred})
    if "DTC" in df.columns:
        out["DTC_true"] = df["DTC"].to_numpy()
        out["residual"] = out["DTC_pred"] - out["DTC_true"]
        ok = out["DTC_true"].notna()
        metrics = compute_metrics(out.loc[ok, "DTC_true"].to_numpy(), out.loc[ok, "DTC_pred"].to_numpy(),
                                  np.zeros(int(ok.sum()), dtype=int))
        print(f"  与实测 DTC 对比：MAE={metrics['MAE']:.3f}  RMSE={metrics['RMSE']:.3f}  R2={metrics['R2']:.4f}  n={metrics['n']}")
    else:
        metrics = None
        print("  该井没有实测 DTC，仅输出预测值")
    out.to_csv(out_csv, index=False, encoding="utf-8-sig")
    plot_well(df, pred, f"{well_name}  DTC 预测", out_png, metrics)
    print(f"  已保存 {out_csv}\n  已保存 {out_png}")


if __name__ == "__main__":
    main()
